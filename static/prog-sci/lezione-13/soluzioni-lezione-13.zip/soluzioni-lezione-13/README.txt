SOLUZIONI DEGLI ESERCIZI — LEZIONE 13

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio veloce: cosa stampa?
    cartella: esercizio-veloce-cosa-stampa
    file:     lampo.cpp
    compila:  g++ -std=c++17 -Wall lampo.cpp -o esegui
    stampa:
        1 2 3

* Soluzione dell'esercizio: `Casuale`
    cartella: soluzione-dell-esercizio-casuale
    file:     esercizio_generatore.cpp
    compila:  g++ -std=c++17 -Wall esercizio_generatore.cpp -o esegui
    stampa:
        0.796543 0.183435

