SOLUZIONI DEGLI ESERCIZI — LEZIONE 13

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio veloce: cosa stampa?
    cartella: esercizio-veloce-cosa-stampa
    file:     lampo.cpp
    compila:  g++ -std=c++17 -Wall lampo.cpp -o esegui
    stampa:
        1 2 3

* Soluzione dell'esercizio sul registro
    cartella: soluzione-dell-esercizio-sul-registro
    file:     esercizio_registro.cpp
    compila:  g++ -std=c++17 -Wall esercizio_registro.cpp -o esegui
    stampa:
        [1] inizio
        [2] dati caricati
        [3] fine

