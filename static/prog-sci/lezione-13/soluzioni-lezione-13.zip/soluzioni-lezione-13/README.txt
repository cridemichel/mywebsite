SOLUZIONI DEGLI ESERCIZI — LEZIONE 13

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio veloce: cosa stampa?
    cartella: esercizio-veloce-cosa-stampa
    file:     lampo.cpp
    compila:  g++ -std=c++17 -Wall lampo.cpp -o esegui
    stampa:
        1 2 3

* Soluzione dell'esercizio sul contatore
    cartella: soluzione-dell-esercizio-sul-contatore
    file:     esercizio_contatore.cpp
    compila:  g++ -std=c++17 -Wall esercizio_contatore.cpp -o esegui
    stampa:
        all'inizio: 0
        dopo tre: 3
        dopo la copia: 4
        alla fine: 0

