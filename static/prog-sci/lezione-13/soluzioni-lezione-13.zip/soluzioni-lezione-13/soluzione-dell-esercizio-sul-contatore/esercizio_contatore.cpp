#include <iostream>

class Particella {
private:
    static int totale_;
    double massa_;
public:
    Particella(double massa) : massa_(massa) { totale_++; }
    Particella(const Particella& altra)
        : massa_(altra.massa_) { totale_++; }
    ~Particella() { totale_--; }
    double massa() const { return massa_; }
    static int quante() { return totale_; }
};

int Particella::totale_ = 0;

int main() {
    std::cout << "all'inizio: " << Particella::quante() << "\n";
    {
        Particella p1(1.0), p2(2.0), p3(3.0);
        std::cout << "dopo tre: " << Particella::quante() << "\n";
        Particella p4 = p1;
        std::cout << "dopo la copia: " << Particella::quante() << "\n";
    }
    std::cout << "alla fine: " << Particella::quante() << "\n";
    return 0;
}
