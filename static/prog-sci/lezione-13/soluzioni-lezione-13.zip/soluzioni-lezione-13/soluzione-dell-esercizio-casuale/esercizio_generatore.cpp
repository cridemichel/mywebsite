#include <iostream>
#include <random>

class Casuale {
private:
    std::mt19937 motore;
    std::uniform_real_distribution<double> uniforme;
    Casuale() {}
public:
    Casuale(const Casuale&) = delete;
    Casuale& operator=(const Casuale&) = delete;
    static Casuale& get() {
        static Casuale unico;
        return unico;
    }
    void seed(int s) { motore.seed(s); }
    double ranf() { return uniforme(motore); }
};

class Strato {
public:
    double w;
    Strato() { w = Casuale::get().ranf(); }
};

int main() {
    Casuale::get().seed(42);
    Strato a, b;
    std::cout << a.w << " " << b.w << "\n";
    return 0;
}
