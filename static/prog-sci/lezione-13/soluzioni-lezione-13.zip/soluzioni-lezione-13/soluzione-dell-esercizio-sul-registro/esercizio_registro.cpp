#include <iostream>
#include <string>

class Registro {
private:
    int n_ = 0;
    Registro() {}
public:
    Registro(const Registro&) = delete;
    Registro& operator=(const Registro&) = delete;
    static Registro& get() {
        static Registro unico;
        return unico;
    }
    void scrivi(const std::string& messaggio) {
        n_++;
        std::cout << "[" << n_ << "] " << messaggio << "\n";
    }
};

void carica_dati() {
    Registro::get().scrivi("dati caricati");
}

int main() {
    Registro::get().scrivi("inizio");
    carica_dati();
    Registro::get().scrivi("fine");
    return 0;
}
