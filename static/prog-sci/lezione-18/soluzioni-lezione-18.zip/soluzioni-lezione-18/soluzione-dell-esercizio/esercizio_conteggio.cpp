#include <iostream>
#include <map>
#include <vector>

int main() {
    // le prime 20 etichette di mnist_train.csv
    std::vector<int> etichette = {5, 0, 4, 1, 9, 2, 1, 3, 1, 4, 3, 5, 3, 6, 1, 7, 2, 8, 6, 9};
    std::map<int, int> conteggio;    // cifra -> quante volte compare
    for (int e : etichette) {
        conteggio[e]++;
    }
    for (const auto& p : conteggio) {
        std::cout << p.first << ": " << p.second << "\n";
    }
    auto it = conteggio.find(9);
    if (it != conteggio.end()) {
        std::cout << "il 9 compare " << it->second << " volte\n";
    }
    std::cout << conteggio.size() << " cifre diverse\n";
    return 0;
}
