#include <algorithm>
#include <iostream>
#include <map>
#include <vector>

int main() {
    std::vector<int> etichette = {5, 0, 4, 1, 9, 2, 1, 3, 1, 4, 3, 5, 3, 6, 1, 7, 2, 8, 6, 9};
    std::map<int, int> conteggio;
    for (int e : etichette) {
        conteggio[e]++;
    }
    auto it = std::max_element(conteggio.begin(), conteggio.end(),
        [](const auto& a, const auto& b) { return a.second < b.second; });
    std::cout << "la cifra " << it->first << " compare " << it->second << " volte\n";
    int n = std::count_if(conteggio.begin(), conteggio.end(),
        [](const auto& p) { return p.second >= 3; });
    std::cout << n << " cifre compaiono almeno 3 volte\n";
    std::sort(etichette.begin(), etichette.end(), [](int a, int b) { return a > b; });
    for (int e : etichette) std::cout << e << " ";
    std::cout << "\n";
    return 0;
}
