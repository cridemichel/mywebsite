SOLUZIONI DEGLI ESERCIZI — LEZIONE 18

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Soluzione dell'esercizio
    cartella: soluzione-dell-esercizio
    file:     esercizio_conteggio.cpp
    compila:  g++ -std=c++17 -Wall esercizio_conteggio.cpp -o esegui
    stampa:
        0: 1
        1: 4
        2: 2
        3: 3
        4: 2
        5: 2
        6: 2
        7: 1
        8: 1
        9: 2
        il 9 compare 2 volte
        10 cifre diverse

* Soluzione del secondo esercizio
    cartella: soluzione-del-secondo-esercizio
    file:     esercizio_frequenze.cpp
    compila:  g++ -std=c++17 -Wall esercizio_frequenze.cpp -o esegui
    stampa:
        la cifra 1 compare 4 volte
        2 cifre compaiono almeno 3 volte
        9 9 8 7 6 6 5 5 4 4 3 3 3 2 2 1 1 1 1 0

