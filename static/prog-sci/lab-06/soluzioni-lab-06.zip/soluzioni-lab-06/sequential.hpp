#ifndef SEQUENTIAL_HPP
#define SEQUENTIAL_HPP

#include <vector>
#include "layer.hpp"

// Task 3: la rete, una sequenza di layer di cui e' proprietaria
class Sequential {
private:
    std::vector<Layer*> layers;   // i layer, creati con new

public:
    Sequential() {}
    ~Sequential();                                       // distrugge i layer

    Sequential(const Sequential&) = delete;              // copia vietata
    Sequential& operator=(const Sequential&) = delete;   // assegnamento vietato

    void add(Layer* layer);
    Eigen::MatrixXd forward(const Eigen::MatrixXd& input);
    int size() const { return layers.size(); }
};

#endif
