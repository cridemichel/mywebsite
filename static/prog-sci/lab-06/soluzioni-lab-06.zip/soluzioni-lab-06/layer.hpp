#ifndef LAYER_HPP
#define LAYER_HPP

#include <Eigen/Dense>

// Task 1: la classe base astratta di tutti i layer (Lezione 12)
class Layer {
public:
    virtual ~Layer() {}
    virtual Eigen::MatrixXd forward(const Eigen::MatrixXd& input) = 0;
};

#endif
