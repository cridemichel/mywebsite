SOLUZIONE DEL LABORATORIO 06 — La classe astratta Layer e la rete Sequential

Lo stato del framework al termine di questo laboratorio.
E' anche il PUNTO DI PARTENZA del laboratorio successivo.

File:
  - CMakeLists.txt
  - layer.hpp
  - main.cpp
  - matrix.cpp
  - matrix.hpp
  - parametricLayer.cpp
  - parametricLayer.hpp
  - sequential.cpp
  - sequential.hpp

Come si compila:
  cmake -B build
  cmake --build build

Verifica automatica: ok (compila)
