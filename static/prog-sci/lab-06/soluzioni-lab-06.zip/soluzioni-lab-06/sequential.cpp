#include "sequential.hpp"

// Task 4, da scrivere: distrugge ogni layer con delete
Sequential::~Sequential() {
    for (Layer* l : layers) {
        delete l;
    }
}

// Task 4, da scrivere: aggiunge il layer in fondo
void Sequential::add(Layer* layer) {
    layers.push_back(layer);
}

// l'uscita di ogni layer e' l'ingresso del successivo
Eigen::MatrixXd Sequential::forward(const Eigen::MatrixXd& input) {
    Eigen::MatrixXd corrente = input;
    for (Layer* l : layers) {
        corrente = l->forward(corrente);
    }
    return corrente;
}
