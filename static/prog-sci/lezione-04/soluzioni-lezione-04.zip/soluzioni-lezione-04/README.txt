SOLUZIONI DEGLI ESERCIZI — LEZIONE 04

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio in classe (15 min): lettura robusta di un numero
    cartella: esercizio-in-classe-lettura-robusta-di-un-nu
    file:     soluzione.cpp
    compila:  g++ -std=c++17 -Wall soluzione.cpp -o esegui
    stampa:
        Quante epoche?

