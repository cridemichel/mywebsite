SOLUZIONI DEGLI ESERCIZI — LEZIONE 04

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio in Classe (15 min): leggere un numero, sul serio
    cartella: esercizio-in-classe-leggere-un-numero-sul-se
    file:     soluzione.cpp
    compila:  g++ -std=c++17 -Wall soluzione.cpp -o esegui
    stampa:
        (il programma aspetta input o non termina: non eseguito qui)

