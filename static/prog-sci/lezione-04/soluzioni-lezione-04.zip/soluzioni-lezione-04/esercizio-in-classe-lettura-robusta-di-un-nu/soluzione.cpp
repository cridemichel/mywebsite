#include <iostream>
#include <limits>

int main() {
    int epoche = 0;
    while (true) {
        std::cout << "Quante epoche? ";
        if (std::cin >> epoche) {                 // lo STATO, non il valore
            if (epoche > 0) break;
            std::cout << "Dev'essere positivo.\n";
        } else {
            if (std::cin.eof()) return 1;                  // fine dell'input
            std::cout << "Quello non e' un numero.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
    }
    std::cout << "Addestro per " << epoche << " epoche.\n";
}
