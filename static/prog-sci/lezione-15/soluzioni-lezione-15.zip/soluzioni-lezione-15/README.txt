SOLUZIONI DEGLI ESERCIZI — LEZIONE 15

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Soluzione dell'esercizio
    cartella: soluzione-dell-esercizio
    file:     esercizio_ottimizzatore.cpp
    compila:  g++ -std=c++17 -Wall esercizio_ottimizzatore.cpp -o esegui
    stampa:
        Adam
        1

