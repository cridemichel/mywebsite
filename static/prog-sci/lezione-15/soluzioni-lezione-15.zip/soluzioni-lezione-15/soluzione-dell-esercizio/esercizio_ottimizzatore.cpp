#include <iostream>
#include <string>

enum class OptimizerType { SGD, ADAM, RMSPROP };

std::string nome(OptimizerType opt) {
    switch (opt) {
        case OptimizerType::SGD:     return "SGD";
        case OptimizerType::ADAM:    return "Adam";
        case OptimizerType::RMSPROP: return "RMSprop";
    }
    return "";
}

int main() {
    OptimizerType opt = OptimizerType::ADAM;
    std::cout << nome(opt) << "\n";
    std::cout << static_cast<int>(opt) << "\n";
    return 0;
}
