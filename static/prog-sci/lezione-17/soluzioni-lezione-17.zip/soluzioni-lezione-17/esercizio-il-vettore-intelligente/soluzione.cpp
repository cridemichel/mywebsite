#include <iostream>
#include <memory>
#include <vector>

class Layer {
public:
    virtual ~Layer() { std::cout << "Layer distrutto\n"; }
};

class DenseLayer : public Layer {
    std::string nome_;
public:
    DenseLayer(std::string n) : nome_(n) {}
    ~DenseLayer() override { std::cout << "DenseLayer " << nome_ << " distrutto\n"; }
};

// (va incollato sotto il blocco della slide precedente)
int main() {
    std::vector<std::unique_ptr<Layer>> rete;

    rete.push_back(std::make_unique<DenseLayer>("L1"));
    rete.push_back(std::make_unique<DenseLayer>("L2"));

    auto l3 = std::make_unique<DenseLayer>("L3");
    rete.push_back(std::move(l3));

    std::cout << "Fine del main. Nessun delete scritto da me.\n";
}
