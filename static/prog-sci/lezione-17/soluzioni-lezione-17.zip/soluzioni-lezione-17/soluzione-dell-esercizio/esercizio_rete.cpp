#include <iostream>
#include <memory>
#include <utility>
#include <vector>

class Layer {
public:
    virtual ~Layer() { std::cout << "~Layer\n"; }
};

class DenseLayer : public Layer {
private:
    int Nn_, Ni_;
public:
    DenseLayer(int Nn, int Ni) : Nn_(Nn), Ni_(Ni) {}
    ~DenseLayer() override {
        std::cout << "~DenseLayer " << Nn_ << "x" << Ni_ << "\n";
    }
};
int main() {
    std::vector<std::unique_ptr<Layer>> rete;
    rete.push_back(std::make_unique<DenseLayer>(128, 784));
    std::unique_ptr<Layer> u = std::make_unique<DenseLayer>(10, 128);
    rete.push_back(std::move(u));
    std::cout << "fine del main\n";
    return 0;
}
