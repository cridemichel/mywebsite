SOLUZIONI DEGLI ESERCIZI — LEZIONE 17

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio: Il Vettore Intelligente (10 min)
    cartella: esercizio-il-vettore-intelligente
    file:     soluzione.cpp
    compila:  g++ -std=c++17 -Wall soluzione.cpp -o esegui
    stampa:
        Fine del main. Nessun delete scritto da me.
        DenseLayer L3 distrutto
        Layer distrutto
        DenseLayer L2 distrutto
        Layer distrutto
        DenseLayer L1 distrutto
        Layer distrutto

