SOLUZIONI DEGLI ESERCIZI — LEZIONE 17

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Soluzione dell'esercizio
    cartella: soluzione-dell-esercizio
    file:     esercizio_rete.cpp
    compila:  g++ -std=c++17 -Wall esercizio_rete.cpp -o esegui
    stampa:
        fine del main
        ~DenseLayer 10x128
        ~Layer
        ~DenseLayer 128x784
        ~Layer

* Soluzione dell'esercizio facoltativo
    cartella: soluzione-dell-esercizio-facoltativo
    file:     esercizio_albero.cpp
    compila:  g++ -std=c++17 -Wall esercizio_albero.cpp -o esegui
    stampa:
        100  6.5824  12.39
        1000  10.9841  21.19
        10000  15.715  30.47

