#include <iostream>
#include <memory>
#include <random>
#include <utility>

struct Nodo {
    double dato;
    Nodo* su = nullptr;                      // il genitore: non lo possiede
    std::unique_ptr<Nodo> sinistra, destra;  // i figli: li possiede
    Nodo(double d) : dato(d) {}
};

int profondita(const Nodo* p) {
    int h = 0;
    while (p->su != nullptr) {
        p = p->su;
        h++;
    }
    return h;
}
void inserisci(std::unique_ptr<Nodo> nuovo, Nodo* vecchio) {
    if (nuovo->dato <= vecchio->dato) {
        if (vecchio->sinistra == nullptr) {
            nuovo->su = vecchio;
            vecchio->sinistra = std::move(nuovo);
        } else {
            inserisci(std::move(nuovo), vecchio->sinistra.get());
        }
    } else {
        if (vecchio->destra == nullptr) {
            nuovo->su = vecchio;
            vecchio->destra = std::move(nuovo);
        } else {
            inserisci(std::move(nuovo), vecchio->destra.get());
        }
    }
}
int main() {
    std::mt19937 motore(12345);
    std::uniform_real_distribution<double> uniforme(0.0, 1.0);
    const int R = 100;                                // alberi per ogni N
    for (int N = 100; N <= 10000; N *= 10) {
        double media = 0.0, massima = 0.0;
        for (int r = 0; r < R; r++) {                 // media su R realizzazioni
            std::unique_ptr<Nodo> radice = std::make_unique<Nodo>(uniforme(motore));
            int somma = 0;                            // la radice ha profondita' 0
            int hmax = 0;
            for (int i = 1; i < N; i++) {
                std::unique_ptr<Nodo> nuovo = std::make_unique<Nodo>(uniforme(motore));
                Nodo* p = nuovo.get();                // l'indirizzo, prima di cederlo
                inserisci(std::move(nuovo), radice.get());
                int h = profondita(p);
                somma += h;
                if (h > hmax) hmax = h;
            }
            media += static_cast<double>(somma) / N;
            massima += hmax;
        }                                             // qui radice distrugge l'albero
        std::cout << N << "  " << media / R << "  " << massima / R << "\n";
    }
    return 0;
}
