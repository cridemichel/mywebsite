#include <cmath>
#include <iostream>
#include <string>
#include <vector>

class Loss {
public:
    virtual ~Loss() {}
    virtual double forward(double p, double t) const = 0;
    virtual std::string get_type() const = 0;
};

class MSELoss : public Loss {
public:
    double forward(double p, double t) const override {
        return (p - t) * (p - t);
    }
    std::string get_type() const override {
        return "MSELoss";
    }
};
