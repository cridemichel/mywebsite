SOLUZIONI DEGLI ESERCIZI — LEZIONE 12

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio sulle loss: le classi date
    cartella: esercizio-sulle-loss-le-classi-date
    file:     loss.cpp
    compila:  g++ -std=c++17 -Wall -c loss.cpp

* Approfondimento: esercizio lampo
    cartella: lampo/approfondimento-esercizio-lampo
    file:     lampo.cpp
    compila:  g++ -std=c++17 -Wall lampo.cpp -o esegui
    stampa:
        DenseLayer, livello 1

* Esercizio sulla discesa: i file dati
    cartella: esercizio-sulla-discesa-i-file-dati
    file:     Funzione2D.hpp
    compila:  None

