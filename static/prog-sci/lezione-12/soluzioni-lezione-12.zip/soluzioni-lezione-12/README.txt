SOLUZIONI DEGLI ESERCIZI — LEZIONE 12

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio sulle loss: le classi date
    cartella: esercizio-sulle-loss-le-classi-date
    file:     loss.cpp
    compila:  g++ -std=c++17 -Wall loss.cpp -o esegui
    stampa:
        MSELoss: 0.25
        AbsLoss: 0.5

* Approfondimento: esercizio lampo
    cartella: lampo/approfondimento-esercizio-lampo
    file:     lampo.cpp
    compila:  g++ -std=c++17 -Wall lampo.cpp -o esegui
    stampa:
        DenseLayer, livello 1

* Esercizio sulla discesa: i file dati
    cartella: esercizio-sulla-discesa-i-file-dati
    file:     Funzione2D.hpp, Vettore2D.hpp, Vettore2D.cpp, discesa.cpp
    compila:  g++ -std=c++17 -Wall Vettore2D.cpp discesa.cpp -o esegui
    stampa:
        Paraboloide, eta = 0.2: 32 passi, x = (1.59173e-07, 7.95866e-08), F = 5.06722e-14
        Rosenbrock, eta = 0.001: 32076 passi, x = (0.999999, 0.999998), F = 1.25172e-12
        Rosenbrock, eta = 0.0019: 16851 passi, x = (0.999999, 0.999998), F = 1.25181e-12
        Rosenbrock, eta = 0.002: non converge, x = (1.00041, 0.997295), F = 0.00124955

