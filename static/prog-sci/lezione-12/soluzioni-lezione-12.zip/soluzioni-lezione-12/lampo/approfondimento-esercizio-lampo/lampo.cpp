#include <iostream>
class Layer {
public:
    virtual ~Layer() {}
    virtual void info(int livello = 1) const {
        std::cout << "Layer, livello " << livello << "\n";
    }
};

class DenseLayer : public Layer {
public:
    void info(int livello = 2) const override {
        std::cout << "DenseLayer, livello " << livello << "\n";
    }
};

int main() {
    Layer* p = new DenseLayer();
    p->info();
    delete p;
    return 0;
}
