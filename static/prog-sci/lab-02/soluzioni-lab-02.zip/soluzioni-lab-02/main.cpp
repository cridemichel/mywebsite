#include <iostream>
#include <cmath>

// Soluzione del Laboratorio 02.
// Ogni task sta in un blocco { ... }: le graffe aprono uno scope (Lezione 04),
// quindi le variabili di un task (x, w1, E, ...) non si vedono negli altri e i
// nomi si possono riusare senza ombreggiature.

int main() {
    // ---- Task 1 -------------------------------------------------------------
    std::cout << "Inizio progetto BASIC_NEURAL++!" << std::endl;

    // ---- Task 2: tipi base e divisione intera --------------------------------
    {
        int epochs = 100;
        double learning_rate = 0.01;
        std::cout << "\n[Task 2] epoche: " << epochs
                  << ", learning rate: " << learning_rate << std::endl;

        int a = 5, b = 2;
        std::cout << "5 / 2 = " << a / b << " (divisione intera)" << std::endl;
        std::cout << "con il cast = " << static_cast<double>(a) / b << std::endl;
    }

    // ---- Task 3: discesa del gradiente su E(x) = x^2 (quesito 1, Lezione 03) --
    {
        std::cout << "\n[Task 3] E(x) = x^2, x0 = 1" << std::endl;
        for (int k = 1; k <= 5; ++k) {
            double eta = 0.25 * k;              // int * double: k diventa double
            double x = 1.0;
            std::cout << "eta = " << eta << ":";
            for (int n = 1; n <= 5; ++n) {
                x = x - eta * 2.0 * x;          // E'(x) = 2x
                std::cout << "  " << x;
            }
            std::cout << std::endl;
        }
    }

    // ---- Task 4: l'esercizio in classe della Lezione 03 ----------------------
    {
        double x = 1.0, y = 1.0;
        double w1 = 1.0, w2 = 1.0;

        // forward
        double z1 = w1 * x;
        double a1 = 1.0 / (1.0 + std::exp(-z1));
        double z2 = w2 * a1;
        double a2 = 1.0 / (1.0 + std::exp(-z2));
        double E  = (a2 - y) * (a2 - y);

        // backward
        double s1 = a1 * (1.0 - a1);            // sigma'(z1) = sigma(1 - sigma)
        double s2 = a2 * (1.0 - a2);            // sigma'(z2)
        double delta2 = 2.0 * (a2 - y) * s2;
        double delta1 = w2 * delta2 * s1;
        double dE_dw2 = delta2 * a1;
        double dE_dw1 = delta1 * x;

        std::cout << "\n[Task 4]\tstrato 1\tstrato 2" << std::endl;
        std::cout << "z\t\t" << z1 << "\t" << z2 << std::endl;
        std::cout << "a\t\t" << a1 << "\t" << a2 << std::endl;
        std::cout << "sigma'(z)\t" << s1 << "\t" << s2 << std::endl;
        std::cout << "delta\t\t" << delta1 << "\t" << delta2 << std::endl;
        std::cout << "dE/dw\t\t" << dE_dw1 << "\t" << dE_dw2 << std::endl;
        std::cout << "E = " << E << ",  delta1/delta2 = " << delta1 / delta2 << std::endl;

        // gradient check: lo stesso forward, con w1 spostato di +h e di -h.
        // Senza funzioni (Lezione 05) va ricopiato: nel Lab 03 diventera' sigmoid().
        double h = 0.01;
        double a1p = 1.0 / (1.0 + std::exp(-(w1 + h) * x));
        double a2p = 1.0 / (1.0 + std::exp(-w2 * a1p));
        double E_piu = (a2p - y) * (a2p - y);
        double a1m = 1.0 / (1.0 + std::exp(-(w1 - h) * x));
        double a2m = 1.0 / (1.0 + std::exp(-w2 * a1m));
        double E_meno = (a2m - y) * (a2m - y);
        std::cout << "gradient check: (E(w1+h) - E(w1-h)) / 2h = "
                  << (E_piu - E_meno) / (2.0 * h)
                  << "  (backprop: " << dE_dw1 << ")" << std::endl;
    }

    // ---- Task 5: addestrare la catena ----------------------------------------
    {
        double x = 1.0, eta = 1.0;
        for (int caso = 0; caso < 2; ++caso) {
            double y = 1.0;
            if (caso == 1) {
                y = 0.8;
            }
            double w1 = 1.0, w2 = 1.0;
            std::cout << "\n[Task 5] y = " << y << ", eta = " << eta << std::endl;
            for (int t = 0; t <= 200; ++t) {
                double a1 = 1.0 / (1.0 + std::exp(-w1 * x));
                double a2 = 1.0 / (1.0 + std::exp(-w2 * a1));
                double E  = (a2 - y) * (a2 - y);
                double delta2 = 2.0 * (a2 - y) * a2 * (1.0 - a2);
                double delta1 = w2 * delta2 * a1 * (1.0 - a1);
                if (t % 20 == 0) {
                    std::cout << "t = " << t << "\tE = " << E
                              << "\tw1 = " << w1 << "\tw2 = " << w2 << std::endl;
                }
                w1 = w1 - eta * delta1 * x;     // dE/dw1 = delta1 * x
                w2 = w2 - eta * delta2 * a1;    // dE/dw2 = delta2 * a1
            }
        }
    }

    return 0;
}
