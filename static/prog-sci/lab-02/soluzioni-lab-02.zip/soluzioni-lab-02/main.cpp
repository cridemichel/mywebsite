#include <iostream>

int main() {
    std::cout << "Inizio progetto BASIC_NEURAL++!" << std::endl;
    std::cout << "---------------------------------" << std::endl;

    // Task 4: Esplorazione Tipi Base
    int epochs = 100;
    double learning_rate = 0.01;
    double weight = 0.55;

    std::cout << "Parametri di Addestramento:" << std::endl;
    std::cout << "Epoche: " << epochs << std::endl;
    std::cout << "Learning Rate: " << learning_rate << std::endl;
    std::cout << "Peso Iniziale: " << weight << std::endl;

    // Test operazioni miste
    double updated_weight = weight - (learning_rate * 0.1);
    std::cout << "\nPeso Aggiornato: " << updated_weight << std::endl;

    // Dimostrazione divisione intera (spesso fonte di bug in C++)
    int a = 5;
    int b = 2;
    std::cout << "\nDivisione intera (5 / 2) = " << (a / b) << " (Attenzione: taglia i decimali!)" << std::endl;
    std::cout << "Divisione corretta con cast = " << (static_cast<double>(a) / b) << std::endl;

    return 0;
}
