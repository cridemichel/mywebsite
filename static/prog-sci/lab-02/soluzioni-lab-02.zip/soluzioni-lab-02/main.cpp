#include <iostream>

// Soluzione del Laboratorio 02, Task 1: il main.cpp del framework, punto di
// partenza del Laboratorio 03. Gli altri task sono programmi a se', ciascuno
// col suo main(): task2_tipi.cpp, task3_discesa.cpp, task4_backprop.cpp e
// task5_addestramento.cpp. Nel CMakeLists.txt c'e' un eseguibile per task:
//   ./build/basic_neural   ./build/task2   ./build/task3   ./build/task4   ./build/task5

int main() {
    std::cout << "Inizio progetto BASIC_NEURAL++!" << std::endl;
    return 0;
}
