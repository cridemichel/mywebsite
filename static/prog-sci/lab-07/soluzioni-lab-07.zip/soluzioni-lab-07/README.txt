SOLUZIONE DEL LABORATORIO 07 — La sigmoide e le ottimizzazioni del compilatore

Lo stato del framework al termine di questo laboratorio.
E' anche il PUNTO DI PARTENZA del laboratorio successivo.

File:
  - CMakeLists.txt
  - activation_layers.cpp
  - activation_layers.hpp
  - layer.hpp
  - main.cpp
  - parametricLayer.cpp
  - parametricLayer.hpp
  - sequential.cpp
  - sequential.hpp

Come si compila:
  cmake -B build
  cmake --build build

Verifica automatica: ok (compila)
