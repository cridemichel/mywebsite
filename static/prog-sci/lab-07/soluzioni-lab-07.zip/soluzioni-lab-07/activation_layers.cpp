#include "activation_layers.hpp"

// Task 2: sigma(z) = 1 / (1 + exp(-z)), elemento per elemento
Eigen::MatrixXd SigmoidLayer::forward(const Eigen::MatrixXd& input) {
    Eigen::MatrixXd output = 1.0 / (1.0 + (-input.array()).exp());
    return output;
}
