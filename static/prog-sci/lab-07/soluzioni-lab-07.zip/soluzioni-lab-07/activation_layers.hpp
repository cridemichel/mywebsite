#ifndef ACTIVATION_LAYERS_HPP
#define ACTIVATION_LAYERS_HPP

#include "layer.hpp"

// Task 2: la sigmoide, un layer senza pesi
class SigmoidLayer : public Layer {
public:
    Eigen::MatrixXd forward(const Eigen::MatrixXd& input) override;
};

#endif
