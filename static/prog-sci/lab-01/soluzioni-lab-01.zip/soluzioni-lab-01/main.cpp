// Laboratorio 01 — soluzione di riferimento.
// Verifica che l'ambiente sia pronto: Eigen calcola, OpenCV crea un'immagine.
#include <iostream>
#include <Eigen/Dense>
#include <opencv2/opencv.hpp>

int main() {
    Eigen::MatrixXd W = Eigen::MatrixXd::Random(3, 4);
    Eigen::VectorXd x = Eigen::VectorXd::Random(4);

    Eigen::VectorXd z = W * x;
    std::cout << "z e' " << z.rows() << "x" << z.cols() << ":\n" << z << "\n\n";

    // Il primo forward pass: un prodotto matrice-vettore e una non linearita'.
    Eigen::ArrayXd z_relu = z.array().max(0.0);
    std::cout << "dopo la ReLU:\n" << z_relu << "\n\n";

    cv::Mat img(28, 28, CV_8UC1, cv::Scalar(128));
    std::cout << "immagine " << img.rows << "x" << img.cols
              << ", canali: " << img.channels() << "\n";

    // imwrite funziona anche senza finestre grafiche (WSL senza WSLg, ssh).
    // Con una finestra disponibile: cv::imshow("Test MNIST size", img); cv::waitKey(0);
    cv::imwrite("test.png", img);
}
