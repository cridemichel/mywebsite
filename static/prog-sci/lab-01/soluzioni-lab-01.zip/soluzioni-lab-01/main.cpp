// Laboratorio 01 — soluzione di riferimento.
// Verifica che l'ambiente sia pronto: Eigen calcola, OpenCV crea un'immagine.
// Tipi float (Xf), come nel resto del framework.
#include <cstdlib>   // std::srand
#include <ctime>     // std::time
#include <iostream>
#include <Eigen/Dense>
#include <opencv2/opencv.hpp>

int main() {
    // Random() usa std::rand(): senza seme la sequenza e' sempre la stessa.
    // std::srand(std::time(nullptr));   // numeri diversi a ogni esecuzione

    Eigen::MatrixXf W = Eigen::MatrixXf::Random(3, 4);
    Eigen::VectorXf x = Eigen::VectorXf::Random(4);

    Eigen::VectorXf z = W * x;
    std::cout << "z e' " << z.rows() << "x" << z.cols() << ":\n" << z << "\n\n";

    // Il primo forward pass (senza bias): un prodotto matrice-vettore e una non linearita'.
    Eigen::ArrayXf z_relu = z.array().max(0.0f);
    std::cout << "dopo la ReLU:\n" << z_relu << "\n\n";

    cv::Mat img(28, 28, CV_8UC1, cv::Scalar(128));
    std::cout << "immagine " << img.rows << "x" << img.cols
              << ", canali: " << img.channels() << "\n";

    // Prima imwrite: funziona anche senza finestre grafiche (WSL senza WSLg, ssh),
    // quindi il PNG c'e' anche se imshow fallisce.
    cv::imwrite("test.png", img);
    cv::imshow("Test MNIST size", img);   // serve una finestra grafica
    cv::waitKey(0);                        // aspetta un tasto, con la finestra in primo piano
}
