SOLUZIONE DEL LABORATORIO 01 — Setup dell'Ambiente — CMake, Eigen e OpenCV

Lo stato del framework al termine di questo laboratorio.
E' anche il PUNTO DI PARTENZA del laboratorio successivo.

File:
  - CMakeLists.txt
  - main.cpp
  - test.png

Come si compila:
  cmake -B build
  cmake --build build

Verifica automatica: ok (compila)
