#include <iostream>

// Task 5: righe, colonne e dati di una matrice, tenuti insieme
struct CMatrix {
    int rows;
    int cols;
    double* data;   // rows*cols double, in ordine row-major
};

CMatrix cmat_alloc(int rows, int cols) {
    CMatrix m;
    m.rows = rows;
    m.cols = cols;
    m.data = new double[rows * cols];
    return m;
}

void cmat_free(CMatrix& m) {
    delete[] m.data;
    m.data = nullptr;   // delete[] su nullptr non fa nulla
    m.rows = 0;
    m.cols = 0;
}

// elemento (i, j): la riga i occupa cols celle consecutive
double cmat_get(const CMatrix& m, int i, int j) {
    return m.data[i * m.cols + j];
}

void cmat_set(CMatrix& m, int i, int j, double val) {
    m.data[i * m.cols + j] = val;
}

// Task 6: z[j] = somma_i W(j, i) * x[i] + b[j], prodotto matrice-vettore
void layer_forward(const CMatrix& W, const double* x, const double* b, double* z) {
    for (int j = 0; j < W.rows; ++j) {
        double acc = 0.0;
        for (int i = 0; i < W.cols; ++i) {
            acc += cmat_get(W, j, i) * x[i];
        }
        z[j] = acc + b[j];
    }
}

int main() {
    // Task 1: N letto in esecuzione, due array sullo heap
    int N;
    std::cout << "Inserisci il numero di input del neurone (es. 784): ";
    std::cin >> N;
    if (N <= 0) {
        std::cerr << "Errore: N deve essere maggiore di 0!" << std::endl;
        return 1;
    }
    double* input = new double[N];
    double* pesi = new double[N];

    // Task 2: valori di prova
    for (int i = 0; i < N; ++i) {
        input[i] = 1.0;
        pesi[i] = 0.01;
    }

    // Task 3: prodotto scalare piu' il bias
    double b = 0.5;
    double z = 0.0;
    for (int i = 0; i < N; ++i) {
        z += pesi[i] * input[i];
    }
    z += b;
    std::cout << "Risultato del calcolo (Z): " << z << std::endl;

    // Task 4: un delete[] per ogni new[]; senza, in un ciclo di addestramento
    // la memoria persa crescerebbe a ogni passo
    delete[] input;
    delete[] pesi;

    // Task 5 e 6: uno strato di M neuroni
    int M = 3;
    CMatrix W = cmat_alloc(M, N);       // M x N pesi
    double* bias = new double[M];
    double* x = new double[N];
    double* z_out = new double[M];
    for (int i = 0; i < N; ++i) {
        x[i] = 1.0;
    }
    for (int j = 0; j < M; ++j) {
        bias[j] = 0.5;
        for (int i = 0; i < N; ++i) {
            cmat_set(W, j, i, 0.01 * (j + 1));
        }
    }
    layer_forward(W, x, bias, z_out);
    for (int j = 0; j < M; ++j) {
        std::cout << "z_out[" << j << "] = " << z_out[j] << std::endl;
    }

    // Task 7: CMatrix W2 = W; copierebbe il puntatore, non i dati:
    // due cmat_free sullo stesso blocco sarebbero un double free
    cmat_free(W);
    delete[] bias;
    delete[] x;
    delete[] z_out;
    return 0;
}
