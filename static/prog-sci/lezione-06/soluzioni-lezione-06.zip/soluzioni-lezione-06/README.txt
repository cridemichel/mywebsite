SOLUZIONI DEGLI ESERCIZI — LEZIONE 06

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio in classe (15 min)
    cartella: esercizio-in-classe
    file:     soluzione.cpp
    compila:  g++ -std=c++17 -Wall soluzione.cpp -o esegui
    stampa:
        Energia della Particella: 100 Joule

* Esercizi lampo: cosa stampa?
    cartella: lampo/esercizi-lampo-cosa-stampa
    file:     quesito1.cpp
    compila:  g++ -std=c++17 -Wall quesito1.cpp -o esegui
    stampa:
        20
        8

