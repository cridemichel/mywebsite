SOLUZIONI DEGLI ESERCIZI — LEZIONE 06

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio in classe (15 min)
    cartella: esercizio-in-classe
    file:     particella.cpp
    compila:  g++ -std=c++17 -Wall particella.cpp -o esegui
    stampa:
        Energia cinetica: 100 J

* Esercizi lampo: cosa stampa?
    cartella: lampo/esercizi-lampo-cosa-stampa
    file:     quesito1.cpp
    compila:  g++ -std=c++17 -Wall quesito1.cpp -o esegui
    stampa:
        20
        8

* Esercizio finale: misure e statistiche (segue)
    cartella: esercizio-finale-misure-e-statistiche
    file:     soluzione.cpp
    compila:  g++ -std=c++17 -Wall soluzione.cpp -o esegui
    stampa:
        T = 2.002 s, sigma = 0.0192354 s

