#include <iostream>

void f(int v[]) { std::cout << sizeof(v) << "\n"; }

int main() {
    int v[5];
    std::cout << sizeof(v) << "\n";
    f(v);
}
