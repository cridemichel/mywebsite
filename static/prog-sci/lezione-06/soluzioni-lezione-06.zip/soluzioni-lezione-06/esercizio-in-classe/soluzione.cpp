#include <iostream>

class Particella {
private:
    double massa_;
    double velocita_;

public:
    Particella(double m, double v) {
        massa_ = m;
        velocita_ = v;
    }

    double calcola_energia() {
        return 0.5 * massa_ * velocita_ * velocita_;
    }
};

int main() {
    // 1. creazione (istanziazione) dell'oggetto
    Particella protone(2.0, 10.0);

    // std::cout << protone.massa_;

    // 2. chiamata al metodo con l'operatore punto (.)
    double e = protone.calcola_energia();

    std::cout << "Energia della Particella: " << e << " Joule\n";
    return 0;
}
