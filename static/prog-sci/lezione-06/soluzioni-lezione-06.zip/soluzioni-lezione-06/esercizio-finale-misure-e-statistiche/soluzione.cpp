#include <iostream>
#include <cmath>
const int MAX_MISURE = 100;
class Misure {
private:
    double x_[MAX_MISURE];
    int n_;
public:
    Misure() { n_ = 0; }
    void aggiungi(double v) {
        if (n_ < MAX_MISURE) {
            x_[n_] = v;
            ++n_;
        }
    }
    int numero() { return n_; }
    double valore(int i) { return x_[i]; }
};

class Statistiche {
private:
    double media_;
    double sigma_;
public:
    Statistiche(Misure& m) {
        int n = m.numero();
        double somma = 0.0;
        for (int i = 0; i < n; ++i) somma += m.valore(i);
        media_ = somma / n;
        double s2 = 0.0;
        for (int i = 0; i < n; ++i) {
            double d = m.valore(i) - media_;
            s2 += d * d;
        }
        sigma_ = std::sqrt(s2 / (n - 1));
    }
    double media() { return media_; }
    double sigma() { return sigma_; }
};

int main() {
    Misure periodo;
    periodo.aggiungi(2.01);
    periodo.aggiungi(1.98);
    periodo.aggiungi(2.03);
    periodo.aggiungi(1.99);
    periodo.aggiungi(2.00);

    Statistiche s(periodo);
    std::cout << "T = " << s.media() << " s, sigma = " << s.sigma() << " s\n";
    return 0;
}
