SOLUZIONI DEGLI ESERCIZI — LEZIONE 16

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Soluzione dell'esercizio
    cartella: soluzione-dell-esercizio
    file:     esercizio_accumulatore.cpp
    compila:  g++ -std=c++17 -Wall esercizio_accumulatore.cpp -o esegui
    stampa:
        12 4
        0.3 0.15
        ciao mondo

