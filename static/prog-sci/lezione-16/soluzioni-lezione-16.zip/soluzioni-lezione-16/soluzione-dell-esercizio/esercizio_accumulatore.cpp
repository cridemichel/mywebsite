#include <iostream>
#include <string>

template <typename T>
class Accumulatore {
private:
    T somma_;
    int n_;
public:
    Accumulatore() : somma_(T{}), n_(0) {}
    void aggiungi(const T& v) {
        somma_ += v;
        n_++;
    }
    T totale() const { return somma_; }
    int quanti() const { return n_; }
    double media() const {
        if (n_ == 0) return 0.0;
        return static_cast<double>(somma_) / n_;
    }
};
int main() {
    Accumulatore<int> a;
    a.aggiungi(3);
    a.aggiungi(4);
    a.aggiungi(5);
    std::cout << a.totale() << " " << a.media() << "\n";
    Accumulatore<double> b;
    b.aggiungi(0.1);
    b.aggiungi(0.2);
    std::cout << b.totale() << " " << b.media() << "\n";
    return 0;
}
