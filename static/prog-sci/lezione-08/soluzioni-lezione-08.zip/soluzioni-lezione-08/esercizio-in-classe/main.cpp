#include <iostream>
#include "Cerchio.hpp"

int main() {
    Cerchio c(1.5);
    std::cout << "Area = " << c.calcolaArea() << "\n";
    std::cout << "Circonferenza = " << c.calcolaCirconferenza() << "\n";
    return 0;
}
