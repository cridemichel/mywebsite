#pragma once

class Cerchio {
private:
    double raggio_;

public:
    Cerchio(double r);
    double calcolaArea();
    double calcolaCirconferenza();
};
