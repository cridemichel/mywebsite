#pragma once

class Cerchio {
private:
    double raggio_;

public:
    // Costruttore
    Cerchio(double r);
    
    // Metodi
    double calcolaArea();
    double calcolaCirconferenza();
};
