#include "Cerchio.hpp"
#include <cmath>

Cerchio::Cerchio(double r) : raggio_(r > 0.0 ? r : 0.0) {}

double Cerchio::calcolaArea() {
    return M_PI * raggio_ * raggio_;
}

double Cerchio::calcolaCirconferenza() {
    return 2.0 * M_PI * raggio_;
}
