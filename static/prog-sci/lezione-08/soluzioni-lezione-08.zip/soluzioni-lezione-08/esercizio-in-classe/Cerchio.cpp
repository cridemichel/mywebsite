#include "Cerchio.hpp"
#include <cmath> // per M_PI

// Implementazione del Costruttore
Cerchio::Cerchio(double r) {
    if (r > 0) raggio_ = r;
    else raggio_ = 0.0;
}

// Implementazione dei Metodi
double Cerchio::calcolaArea() {
    return M_PI * raggio_ * raggio_;
}

double Cerchio::calcolaCirconferenza() {
    return 2.0 * M_PI * raggio_;
}
