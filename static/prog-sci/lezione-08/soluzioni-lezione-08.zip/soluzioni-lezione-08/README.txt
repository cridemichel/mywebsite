SOLUZIONI DEGLI ESERCIZI — LEZIONE 08

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio in Classe (15 min)
    cartella: esercizio-in-classe
    file:     Cerchio.hpp, Cerchio.cpp
    compila:  g++ -std=c++17 -Wall -c Cerchio.cpp

* Esercizio (15 min): la matrice che perde
    cartella: esercizio-la-matrice-che-perde
    file:     soluzione.cpp
    compila:  g++ -std=c++17 -Wall soluzione.cpp -o esegui
    stampa:
        W[2][3] = 11

