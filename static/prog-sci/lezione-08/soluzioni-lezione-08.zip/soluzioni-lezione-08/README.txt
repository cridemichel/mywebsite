SOLUZIONI DEGLI ESERCIZI — LEZIONE 08

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio in classe (segue)
    cartella: esercizio-in-classe
    file:     Misure.hpp, Misure.cpp, Statistiche.hpp, Statistiche.cpp, main.cpp
    compila:  g++ -std=c++17 -Wall Misure.cpp Statistiche.cpp main.cpp -o esegui
    stampa:
        T = 2.002 s, sigma = 0.0192354 s

* Esercizio: trovare un memory leak
    cartella: esercizio-trovare-un-memory-leak
    file:     soluzione.cpp
    compila:  g++ -std=c++17 -Wall soluzione.cpp -o esegui
    stampa:
        W[2][3] = 11

