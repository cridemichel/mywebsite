SOLUZIONI DEGLI ESERCIZI — LEZIONE 08

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio in classe (segue)
    cartella: esercizio-in-classe
    file:     Cerchio.hpp, Cerchio.cpp, main.cpp
    compila:  g++ -std=c++17 -Wall Cerchio.cpp main.cpp -o esegui
    stampa:
        Area = 7.06858
        Circonferenza = 9.42478

* Esercizio: la matrice che perde
    cartella: esercizio-la-matrice-che-perde
    file:     soluzione.cpp
    compila:  g++ -std=c++17 -Wall soluzione.cpp -o esegui
    stampa:
        W[2][3] = 11

