#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

void scrivi_csv() {
    std::ofstream os("finto_mnist.csv");
    os << "label,p0,p1,p2\n";
    os << "3,0,128,255\n";
    os << "1,0,0,255\n";
}   // qui os viene distrutto: il file è chiuso
