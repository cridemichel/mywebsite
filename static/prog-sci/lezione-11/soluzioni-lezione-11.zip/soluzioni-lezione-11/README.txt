SOLUZIONI DEGLI ESERCIZI — LEZIONE 11

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio: `scrivi_csv`, già scritta
    cartella: esercizio-scrivi-csv-gi-scritta
    file:     csv.cpp
    compila:  g++ -std=c++17 -Wall -c csv.cpp

