SOLUZIONI DEGLI ESERCIZI — LEZIONE 11

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio: la funzione data
    cartella: esercizio-la-funzione-data
    file:     csv.cpp
    compila:  g++ -std=c++17 -Wall csv.cpp -o esegui
    stampa:
        Trovata immagine del numero: 3. Pixel: 0 128 255
        Trovata immagine del numero: 1. Pixel: 0 0 255

