SOLUZIONE DEL LABORATORIO 03 — Tipi Base e Funzioni di Attivazione

Lo stato del framework al termine di questo laboratorio.
E' anche il PUNTO DI PARTENZA del laboratorio successivo.

File:
  - CMakeLists.txt
  - main.cpp

Come si compila:
  cmake -B build
  cmake --build build

Verifica automatica: ok (compila)
