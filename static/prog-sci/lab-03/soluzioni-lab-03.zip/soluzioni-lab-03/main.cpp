#include <iostream>
#include <cmath>
#include <iomanip> // per std::setprecision e std::setw

// ==========================================
// TASK 1: ReLU
// ==========================================
double relu(double x) {
    if (x > 0.0) {
        return x;
    } else {
        return 0.0;
    }
}

// ==========================================
// TASK 2: Derivata della ReLU
// ==========================================
double relu_derivative(double x) {
    if (x > 0.0) {
        return 1.0;
    } else {
        return 0.0;
    }
}

// ==========================================
// TASK 3: Sigmoide e sua derivata
// ==========================================
double sigmoid(double x) {
    return 1.0 / (1.0 + std::exp(-x));
}

double sigmoid_derivative(double x) {
    double sig = sigmoid(x);
    return sig * (1.0 - sig);
}

// ==========================================
// TASK 5: Tangente iperbolica e sua derivata
// ==========================================
double tanh_act(double x) {
    return std::tanh(x);
}

double tanh_derivative(double x) {
    double t = std::tanh(x);
    return 1.0 - t * t;
}

// ==========================================
// TASK 6: Verifica numerica delle derivate
// ==========================================
// Derivata numerica con differenze centrali: (f(x+h) - f(x-h)) / (2h).
// Ne scriviamo una per funzione: i puntatori a funzione arrivano piu' avanti.
double sigmoid_numerical_derivative(double x, double h) {
    return (sigmoid(x + h) - sigmoid(x - h)) / (2.0 * h);
}

double tanh_numerical_derivative(double x, double h) {
    return (tanh_act(x + h) - tanh_act(x - h)) / (2.0 * h);
}

int main() {
    std::cout << "Test delle Funzioni di Attivazione" << std::endl;
    std::cout << "==================================" << std::endl;
    
    // Impostiamo la formattazione dell'output per incolonnare bene
    std::cout << std::fixed << std::setprecision(4);
    std::cout << "x\t| ReLU\t\tReLU'\t| Sigmoid\tSigmoid'" << std::endl;
    std::cout << "--------------------------------------------------------" << std::endl;

    // ==========================================
    // TASK 4: Validazione con Ciclo For
    // ==========================================
    for (double x = -5.0; x <= 5.0; x += 1.0) {
        std::cout << std::setw(4) << x << "\t| "
                  << std::setw(6) << relu(x) << "\t" 
                  << std::setw(6) << relu_derivative(x) << "\t| "
                  << std::setw(7) << sigmoid(x) << "\t" 
                  << std::setw(7) << sigmoid_derivative(x) 
                  << std::endl;
    }

    // ==========================================
    // TASK 5: la tanh nella tabella
    // ==========================================
    std::cout << "\nx\t| tanh\t\ttanh'" << std::endl;
    std::cout << "--------------------------------" << std::endl;
    for (double x = -5.0; x <= 5.0; x += 1.0) {
        std::cout << std::setw(4) << x << "\t| "
                  << std::setw(7) << tanh_act(x) << "\t"
                  << std::setw(7) << tanh_derivative(x) << std::endl;
    }

    // ==========================================
    // TASK 6: le derivate analitiche sono giuste?
    // ==========================================
    // Confrontiamo la formula con la derivata numerica su una griglia di x
    // e teniamo il massimo errore assoluto.
    double h = 1.0e-5;
    double max_err_sigmoid = 0.0;
    double max_err_tanh = 0.0;
    for (double x = -5.0; x <= 5.0; x += 0.5) {
        double e1 = std::fabs(sigmoid_derivative(x) - sigmoid_numerical_derivative(x, h));
        double e2 = std::fabs(tanh_derivative(x) - tanh_numerical_derivative(x, h));
        if (e1 > max_err_sigmoid) max_err_sigmoid = e1;
        if (e2 > max_err_tanh) max_err_tanh = e2;
    }
    std::cout << std::scientific << std::setprecision(2);
    std::cout << "\nErrore massimo derivata sigmoide: " << max_err_sigmoid << std::endl;
    std::cout << "Errore massimo derivata tanh:     " << max_err_tanh << std::endl;
    if (max_err_sigmoid < 1.0e-6 && max_err_tanh < 1.0e-6) {
        std::cout << "[PASS] Le derivate analitiche sono corrette." << std::endl;
    } else {
        std::cout << "[FAIL] Controlla le formule delle derivate!" << std::endl;
    }

    // Perche' proprio h = 1e-5? Troppo grande: errore di troncamento.
    // Troppo piccolo: cancellazione numerica fra f(x+h) e f(x-h).
    std::cout << "\nh\t\terrore (sigmoide in x = 1)" << std::endl;
    for (double hh = 1.0e-1; hh >= 1.0e-13; hh /= 100.0) {
        double err = std::fabs(sigmoid_derivative(1.0) - sigmoid_numerical_derivative(1.0, hh));
        std::cout << hh << "\t" << err << std::endl;
    }

    return 0;
}
