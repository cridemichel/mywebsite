#include <iostream>
#include <cmath>

// Soluzione del Laboratorio 03

// Task 1: ReLU
double relu(double x) {
    if (x > 0.0) {
        return x;
    } else {
        return 0.0;
    }
}

// Task 2: derivata della ReLU (0 in x = 0)
double relu_derivative(double x) {
    if (x > 0.0) {
        return 1.0;
    } else {
        return 0.0;
    }
}

// Task 3: sigmoide e sua derivata
double sigmoid(double x) {
    return 1.0 / (1.0 + std::exp(-x));
}

double sigmoid_derivative(double x) {
    double s = sigmoid(x);   // una sola volta
    return s * (1.0 - s);
}

// Task 5: tanh e sua derivata (nome tanh_act)
double tanh_act(double x) {
    return std::tanh(x);
}

double tanh_derivative(double x) {
    double t = std::tanh(x); // una sola volta
    return 1.0 - t * t;
}

// Task 6: derivate numeriche (differenze centrali)
double sigmoid_numerical_derivative(double x, double h) {
    return (sigmoid(x + h) - sigmoid(x - h)) / (2.0 * h);
}

double tanh_numerical_derivative(double x, double h) {
    return (tanh_act(x + h) - tanh_act(x - h)) / (2.0 * h);
}

int main() {
    // Task 4 e 5: tabella da -5 a 5 a passi di 1, contatore int
    std::cout << "x\trelu\trelu'\tsigmoid\tsigmoid'\ttanh\ttanh'" << std::endl;
    for (int i = -5; i <= 5; ++i) {
        double x = i;
        std::cout << x << "\t" << relu(x) << "\t" << relu_derivative(x) << "\t"
                  << sigmoid(x) << "\t" << sigmoid_derivative(x) << "\t"
                  << tanh_act(x) << "\t" << tanh_derivative(x) << std::endl;
    }

    // Task 6: massimo errore assoluto su x da -5 a 5 a passi di 0,5
    double h = 1e-5;
    double max_err_sigmoid = 0.0;
    double max_err_tanh = 0.0;
    for (int i = -10; i <= 10; ++i) {
        double x = 0.5 * i;
        double e1 = std::fabs(sigmoid_derivative(x) - sigmoid_numerical_derivative(x, h));
        double e2 = std::fabs(tanh_derivative(x) - tanh_numerical_derivative(x, h));
        if (e1 > max_err_sigmoid) max_err_sigmoid = e1;
        if (e2 > max_err_tanh) max_err_tanh = e2;
    }
    std::cout << std::scientific;
    std::cout << "\nerrore massimo sigmoide: " << max_err_sigmoid << std::endl;
    std::cout << "errore massimo tanh:     " << max_err_tanh << std::endl;
    if (max_err_sigmoid < 1e-6 && max_err_tanh < 1e-6) {
        std::cout << "[PASS]" << std::endl;
    } else {
        std::cout << "[FAIL]" << std::endl;
    }

    // Task 6, punto 4: errore in x = 1 per h = 1e-1, 1e-3, ..., 1e-13
    std::cout << "\nh\t\terrore sigmoide\terrore tanh" << std::endl;
    for (int k = 1; k <= 13; k += 2) {
        double hh = std::pow(10.0, -k);
        double e1 = std::fabs(sigmoid_derivative(1.0) - sigmoid_numerical_derivative(1.0, hh));
        double e2 = std::fabs(tanh_derivative(1.0) - tanh_numerical_derivative(1.0, hh));
        std::cout << hh << "\t" << e1 << "\t" << e2 << std::endl;
    }
    return 0;
}
