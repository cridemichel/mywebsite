#include <iostream>
#include <cmath>

// Task 7 (facoltativo): la catena del Lab 02
// tipo: 0 sigmoide, 1 tanh, 2 ReLU

double attiva(int tipo, double z) {
    if (tipo == 0) {
        return 1.0 / (1.0 + std::exp(-z));
    } else if (tipo == 1) {
        return std::tanh(z);
    } else if (z > 0.0) {
        return z;
    } else {
        return 0.0;
    }
}

double deriva(int tipo, double z) {
    if (tipo == 0) {
        double s = attiva(0, z);
        return s * (1.0 - s);
    } else if (tipo == 1) {
        double t = std::tanh(z);
        return 1.0 - t * t;
    } else if (z > 0.0) {
        return 1.0;
    } else {
        return 0.0;     // anche in z = 0
    }
}

void addestra(int tipo, double y, double w0, double eta) {
    double x = 1.0;
    double w1 = w0, w2 = w0;
    for (int t = 0; t <= 1000; ++t) {
        double z1 = w1 * x;
        double a1 = attiva(tipo, z1);
        double z2 = w2 * a1;
        double a2 = attiva(tipo, z2);
        double E  = (a2 - y) * (a2 - y);
        double delta2 = 2.0 * (a2 - y) * deriva(tipo, z2);
        double delta1 = w2 * delta2 * deriva(tipo, z1);
        if (t % 500 == 0) {
            std::cout << "t = " << t << "\tE = " << E
                      << "\tw1 = " << w1 << "\tw2 = " << w2 << std::endl;
        }
        w1 = w1 - eta * delta1 * x;
        w2 = w2 - eta * delta2 * a1;
    }
}

int main() {
    // punto 3: w1 = w2 = 0,5 ed eta = 0,25
    for (int tipo = 0; tipo < 3; ++tipo) {
        for (int caso = 0; caso < 2; ++caso) {
            double y = 1.0;
            if (caso == 1) {
                y = 0.8;
            }
            std::cout << "\n[tipo " << tipo << "] y = " << y << std::endl;
            addestra(tipo, y, 0.5, 0.25);
        }
    }
    // punto 4: la ReLU con i parametri del Lab 02, w1 = w2 = 1 ed eta = 1
    std::cout << "\n[ReLU, w0 = 1, eta = 1] y = 1" << std::endl;
    addestra(2, 1.0, 1.0, 1.0);
    std::cout << "\n[ReLU, w0 = 1, eta = 1] y = 0.8" << std::endl;
    addestra(2, 0.8, 1.0, 1.0);
    return 0;
}
