#ifndef PARAMETRIC_LAYER_HPP
#define PARAMETRIC_LAYER_HPP

#include "layer.hpp"

// Uno strato di Nn neuroni con Ni ingressi ciascuno: z = W x + b
class DenseLayer : public Layer {
private:
    Eigen::MatrixXd Wt;       // W: Nn x Ni
    Eigen::MatrixXd biases;   // b: Nn x 1

public:
    // Task 2: neuroni, ingressi e come inizializzare i pesi
    DenseLayer(int Nn, int Ni, InitType type = InitType::HE,
               DistroType distro = DistroType::GAUSSIAN);

    Eigen::MatrixXd forward(
        const Eigen::MatrixXd& input) override;

    const Eigen::MatrixXd& getWeights() const;
    const Eigen::MatrixXd& getBiases() const;
};

#endif
