#include "activation_layers.hpp"

// sigma(z) = 1 / (1 + exp(-z)), elemento per elemento
Eigen::MatrixXd SigmoidLayer::forward(const Eigen::MatrixXd& input) {
    Eigen::MatrixXd output = 1.0 / (1.0 + (-input.array()).exp());
    return output;
}

// Task 4, da scrivere: tanh(z), elemento per elemento
Eigen::MatrixXd TanhLayer::forward(const Eigen::MatrixXd& input) {
    Eigen::MatrixXd output = input.array().tanh();
    return output;
}
