SOLUZIONE DEL LABORATORIO 08 — Tipi enumerati, inizializzazione dei pesi e gerarchia delle attivazioni

Lo stato del framework al termine di questo laboratorio.
E' anche il PUNTO DI PARTENZA del laboratorio successivo.

File:
  - CMakeLists.txt
  - activation_layers.cpp
  - activation_layers.hpp
  - layer.hpp
  - main.cpp
  - parametricLayer.cpp
  - parametricLayer.hpp
  - randnumgen.hpp
  - sequential.cpp
  - sequential.hpp

Come si compila:
  cmake -B build
  cmake --build build

Verifica automatica: ok (compila)
