#ifndef LAYER_HPP
#define LAYER_HPP

#include <Eigen/Dense>

// Task 2: come inizializzare i pesi (Lezione 15): formula di He o di Xavier,
// numeri casuali uniformi o gaussiani
enum class InitType   { HE, XAVIER };
enum class DistroType { UNIFORM, GAUSSIAN };

// la classe base astratta di tutti i layer (Lezione 12)
class Layer {
public:
    virtual ~Layer() {}
    virtual Eigen::MatrixXd forward(const Eigen::MatrixXd& input) = 0;
};

#endif
