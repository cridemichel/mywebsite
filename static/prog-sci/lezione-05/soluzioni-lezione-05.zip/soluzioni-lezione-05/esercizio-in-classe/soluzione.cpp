#include <iostream>
#include <cmath>

void normalizza(double& x, double& y) {
    double norma = std::sqrt(x*x + y*y);
    if (norma > 0) {
        x = x / norma;
        y = y / norma;
    }
}

int main() {
    double x = 3.0;
    double y = 4.0;

    std::cout << "Prima: (" << x << ", " << y << ")\n";

    normalizza(x, y);

    std::cout << "Dopo : (" << x << ", " << y << ")\n";
    return 0;
}
