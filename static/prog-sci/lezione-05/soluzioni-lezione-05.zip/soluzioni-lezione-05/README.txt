SOLUZIONI DEGLI ESERCIZI — LEZIONE 05

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio in classe
    cartella: esercizio-in-classe
    file:     soluzione.cpp
    compila:  g++ -std=c++17 -Wall soluzione.cpp -o esegui
    stampa:
        Prima: (3, 4)
        Dopo : (0.6, 0.8)

