SOLUZIONI DEGLI ESERCIZI — LEZIONE 14

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Soluzione dell'esercizio sui complessi
    cartella: soluzione-dell-esercizio-sui-complessi
    file:     esercizio_complesso.cpp
    compila:  g++ -std=c++17 -Wall esercizio_complesso.cpp -o esegui
    stampa:
        |z| = 2.5
        z = (1.5 + i*2)
        2 * z = (3 + i*4)

* Soluzione dell'esercizio sugli iperparametri
    cartella: soluzione-dell-esercizio-sugli-iperparametri
    file:     esercizio_iperparametri.cpp
    compila:  g++ -std=c++17 -Wall esercizio_iperparametri.cpp -o esegui
    stampa:
        Uso: ./esegui <batch_size> <learning_rate> <dataset>

