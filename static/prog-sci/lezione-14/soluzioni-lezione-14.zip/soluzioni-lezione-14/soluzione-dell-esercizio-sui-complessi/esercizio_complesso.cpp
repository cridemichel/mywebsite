#include <cmath>
#include <iostream>

class Complesso {
private:
    double re_, im_;
public:
    Complesso(double re, double im) : re_(re), im_(im) {}
    double modulo() const { return std::sqrt(re_ * re_ + im_ * im_); }
    friend std::ostream& operator<<(std::ostream& os,
                                    const Complesso& z);
    friend Complesso operator*(double s, const Complesso& z);
};

std::ostream& operator<<(std::ostream& os, const Complesso& z) {
    os << "(" << z.re_ << " + i*" << z.im_ << ")";
    return os;
}

Complesso operator*(double s, const Complesso& z) {
    return Complesso(s * z.re_, s * z.im_);
}

int main() {
    Complesso z(1.5, 2.0);
    std::cout << "|z| = " << z.modulo() << "\n";
    std::cout << "z = " << z << "\n";
    std::cout << "2 * z = " << 2.0 * z << "\n";
    return 0;
}
