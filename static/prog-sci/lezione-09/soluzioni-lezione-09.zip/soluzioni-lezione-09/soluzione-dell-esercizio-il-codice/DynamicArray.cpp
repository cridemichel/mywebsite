#include <iostream>
#include "DynamicArray.hpp"

DynamicArray::DynamicArray(int size) : size_(size), data_(nullptr) {
    data_ = new double[size_];
}

DynamicArray::~DynamicArray() {
    delete[] data_;
    std::cout << "distruttore: liberati " << size_ << " elementi\n";
}

void DynamicArray::imposta(int indice, double valore) {
    if (indice >= 0 && indice < size_) data_[indice] = valore;
}

double DynamicArray::leggi(int indice) const {
    if (indice >= 0 && indice < size_) return data_[indice];
    return 0.0;
}
