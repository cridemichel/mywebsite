SOLUZIONI DEGLI ESERCIZI — LEZIONE 09

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio: header e `main` dati
    cartella: esercizio-header-e-main-dati
    file:     DynamicArray.hpp, main.cpp, DynamicArray.cpp
    compila:  g++ -std=c++17 -Wall main.cpp DynamicArray.cpp -o esegui
    stampa:
        0 0.5 1 1.5 2 
        0
        distruttore: liberati 5 elementi

* Esercizio lampo: cosa stampa?
    cartella: lampo/esercizio-lampo-cosa-stampa
    file:     quesito1.cpp
    compila:  g++ -std=c++17 -Wall quesito1.cpp -o esegui
    stampa:
        fine del blocco
        distrutto 2
        fine del main
        distrutto 3
        distrutto 1

