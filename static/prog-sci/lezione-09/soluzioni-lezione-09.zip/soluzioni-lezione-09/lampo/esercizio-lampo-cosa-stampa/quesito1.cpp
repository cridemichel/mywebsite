#include <iostream>

struct E {
    ~E() { std::cout << "distrutto\n"; }
};

int main() {
    E sullo_stack;
    E* sullo_heap = new E;
    std::cout << "fine main\n";
}
