#include <iostream>

struct E {
    int id;
    E(int i) : id(i) {}
    ~E() { std::cout << "distrutto " << id << "\n"; }
};

int main() {
    E a(1);
    {
        E b(2);
        std::cout << "fine del blocco\n";
    }
    E c(3);
    std::cout << "fine del main\n";
    return 0;
}
