SOLUZIONE DEL LABORATORIO 09 — Il framework diventa un template: float o double

Lo stato del framework al termine di questo laboratorio.
E' anche il PUNTO DI PARTENZA del laboratorio successivo.

File:
  - CMakeLists.txt
  - activation_layers.hpp
  - eigen_wrap.hpp
  - layer.hpp
  - main.cpp
  - parametricLayer.hpp
  - randnumgen.hpp
  - sequential.hpp

Come si compila:
  cmake -B build
  cmake --build build

Verifica automatica: ok (compila)
