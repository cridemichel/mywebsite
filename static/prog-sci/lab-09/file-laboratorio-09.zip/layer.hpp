#ifndef LAYER_HPP
#define LAYER_HPP

#include <Eigen/Dense>

enum class InitType   { HE, XAVIER };            // come inizializzare i pesi (Laboratorio 08)
enum class DistroType { UNIFORM, GAUSSIAN };

// Task 2, da completare: Layer diventa un template sul tipo dei numeri, ntype.
// - al posto di <Eigen/Dense> includete "eigen_wrap.hpp", che definisce Matrix<ntype>;
// - davanti a class Layer scrivete la riga del template, con il parametro ntype;
// - aggiungete un attributo protected, outputs, di tipo Matrix<ntype>;
// - forward riceve un const Matrix<ntype>& e restituisce un Matrix<ntype>&
class Layer {
public:
    virtual ~Layer() {}
    virtual Eigen::MatrixXd forward(const Eigen::MatrixXd& input) = 0;
};
#endif
