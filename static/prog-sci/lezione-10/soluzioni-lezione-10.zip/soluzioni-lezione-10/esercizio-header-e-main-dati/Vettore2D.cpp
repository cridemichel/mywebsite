#include "Vettore2D.hpp"

Vettore2D Vettore2D::operator+(const Vettore2D& altro) const {
    return Vettore2D(x_ + altro.x_, y_ + altro.y_);
}

Vettore2D Vettore2D::operator*(double scalare) const {
    return Vettore2D(x_ * scalare, y_ * scalare);
}
