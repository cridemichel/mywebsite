#include <iostream>

struct S {
    double* p;
};

int main() {
    double x = 1.0;
    S a;
    a.p = &x;
    S b = a;
    *b.p = 2.0;
    std::cout << x << " " << *a.p << "\n";
    return 0;
}
