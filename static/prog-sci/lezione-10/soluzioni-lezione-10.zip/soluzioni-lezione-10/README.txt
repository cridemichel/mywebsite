SOLUZIONI DEGLI ESERCIZI — LEZIONE 10

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio: header e `main` dati
    cartella: esercizio-header-e-main-dati
    file:     Vettore2D.hpp, main.cpp, Vettore2D.cpp
    compila:  g++ -std=c++17 -Wall main.cpp Vettore2D.cpp -o esegui
    stampa:
        15 20

* Esercizio lampo: cosa stampa?
    cartella: lampo/esercizio-lampo-cosa-stampa
    file:     quesito1.cpp
    compila:  g++ -std=c++17 -Wall quesito1.cpp -o esegui
    stampa:
        2 2

* Esercizio: discesa in 2D (segue)
    cartella: esercizio-discesa-in-2d
    file:     Vettore2D.hpp, Vettore2D.cpp, main.cpp
    compila:  g++ -std=c++17 -Wall Vettore2D.cpp main.cpp -o esegui
    stampa:
        eta = 0.1: 69 passi
        eta = 0.2: 32 passi
        eta = 0.24: 191 passi
        eta = 0.26: diverge

