#include "matrix.hpp"
#include <stdexcept>   // invalid_argument, out_of_range

// Task 2: il costruttore fa il lavoro di cmat_alloc e azzera gli elementi
Matrix::Matrix(int r, int c) : rows(r), cols(c) {
    if (r <= 0 || c <= 0) {
        throw std::invalid_argument(
            "Matrix: dimensioni non positive");
    }
    data = new double[rows * cols];
    for (int i = 0; i < rows * cols; i++) {
        data[i] = 0.0;
    }
}

// Task 2: il distruttore fa il lavoro di cmat_free
Matrix::~Matrix() {
    delete[] data;
}

// elemento (r, c): la riga r comincia alla cella r * cols
double Matrix::get(int r, int c) const {
    if (r < 0 || r >= rows || c < 0 || c >= cols) {
        throw std::out_of_range("Matrix::get: indici fuori dai limiti");
    }
    return data[r * cols + c];
}

// Task 2, da scrivere: come get, ma assegna val all'elemento
void Matrix::set(int r, int c, double val) {
    if (r < 0 || r >= rows || c < 0 || c >= cols) {
        throw std::out_of_range("Matrix::set: indici fuori dai limiti");
    }
    data[r * cols + c] = val;
}

int Matrix::getRows() const { return rows; }
int Matrix::getCols() const { return cols; }

// Task 3: un blocco nuovo, con gli stessi valori di altra
Matrix::Matrix(const Matrix& altra)
    : rows(altra.rows), cols(altra.cols),
      data(new double[altra.rows * altra.cols]) {
    for (int i = 0; i < rows * cols; i++) {
        data[i] = altra.data[i];
    }
}

// Task 3, da completare: i quattro passi della Lezione 10
Matrix& Matrix::operator=(const Matrix& altra) {
    if (this == &altra) return *this;  // a. auto-assegnamento: m = m
    delete[] data;                     // b. liberare il vecchio blocco
    rows = altra.rows;                 // c. copiare rows e cols, allocare un
    cols = altra.cols;                 //    blocco nuovo e copiarvi i valori
    data = new double[rows * cols];
    for (int i = 0; i < rows * cols; i++) {
        data[i] = altra.data[i];
    }
    return *this;                      // d. restituire l'oggetto stesso
}
