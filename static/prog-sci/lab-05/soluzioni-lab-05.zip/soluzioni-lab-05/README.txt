SOLUZIONE DEL LABORATORIO 05 — La classe Matrix e il DenseLayer con Eigen

Lo stato del framework al termine di questo laboratorio.
E' anche il PUNTO DI PARTENZA del laboratorio successivo.

File:
  - CMakeLists.txt
  - main.cpp
  - matrix.cpp
  - matrix.hpp
  - parametricLayer.cpp
  - parametricLayer.hpp

Come si compila:
  cmake -B build
  cmake --build build

Verifica automatica: ok (compila)
