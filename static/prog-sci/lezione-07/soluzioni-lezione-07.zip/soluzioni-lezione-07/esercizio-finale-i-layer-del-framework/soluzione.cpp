#include <iostream>

class DenseLayer {
private:
    int Nnodes;
    int Nin;

public:
    DenseLayer(int Nn, int Ni) : Nnodes(Nn), Nin(Ni) { }

    int numParametri() { return Nnodes * Nin; }

    void descrivi() {
        std::cout << "DenseLayer " << Nin << " -> " << Nnodes
                  << ": " << numParametri() << " parametri\n";
    }
};

class SigmoidLayer {
public:
    int numParametri() { return 0; }

    void descrivi() {
        std::cout << "SigmoidLayer: " << numParametri() << " parametri\n";
    }
};

int main() {
    DenseLayer   d1(200, 784);
    SigmoidLayer s1;
    DenseLayer   d2(10, 200);
    SigmoidLayer s2;

    d1.descrivi();
    s1.descrivi();
    d2.descrivi();
    s2.descrivi();

    int totale = d1.numParametri() + s1.numParametri()
               + d2.numParametri() + s2.numParametri();
    std::cout << "Totale: " << totale << " parametri\n";
    return 0;
}
