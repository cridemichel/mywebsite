#include <iostream>

class Neurone {
private:
    double peso_;
    double lr_;

public:
    Neurone() : peso_(0.0), lr_(0.1) {}

    Neurone(double peso, double lr) : peso_(peso), lr_(0.1) { setLr(lr); }

    double getPeso() const { return peso_; }
    double getLr()   const { return lr_;   }

    void setLr(double nuovo) {
        if (nuovo > 0.0 && nuovo <= 1.0) {
            lr_ = nuovo;
        } else {
            std::cerr << "[setLr] rifiutato " << nuovo
                      << ": deve stare in (0, 1]. Tengo " << lr_ << "\n";
        }
    }
};

int main() {
    Neurone n;
    // n.lr_ = 5.0;         // <- il compilatore lo rifiuta
    n.setLr(5.0);           // rifiutato a runtime, con un messaggio
    n.setLr(0.05);          // accettato
    std::cout << "n: lr " << n.getLr() << "\n";

    Neurone m(0.7, 99.0);   // il costruttore passa dal setter
    std::cout << "m: peso " << m.getPeso() << ", lr " << m.getLr() << "\n";
}
