SOLUZIONI DEGLI ESERCIZI — LEZIONE 07

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio veloce: il setter
    cartella: esercizio-veloce-il-setter
    file:     soluzione.cpp
    compila:  g++ -std=c++17 -Wall soluzione.cpp -o esegui
    stampa:
        n: lr 0.05
        m: peso 0.7, lr 0.1
        [setLr] rifiutato 5: deve stare in (0, 1]. Tengo 0.1
        [setLr] rifiutato 99: deve stare in (0, 1]. Tengo 0.1

* Esercizi lampo: cosa stampa?
    cartella: lampo/esercizi-lampo-cosa-stampa
    file:     quesito1.cpp
    compila:  g++ -std=c++17 -Wall quesito1.cpp -o esegui
    stampa:
        default
        copia
        default
        param

* Esercizio finale: i layer del framework (segue)
    cartella: esercizio-finale-i-layer-del-framework
    file:     soluzione.cpp
    compila:  g++ -std=c++17 -Wall soluzione.cpp -o esegui
    stampa:
        DenseLayer 784 -> 200: 156800 parametri
        SigmoidLayer: 0 parametri
        DenseLayer 200 -> 10: 2000 parametri
        SigmoidLayer: 0 parametri
        Totale: 158800 parametri

