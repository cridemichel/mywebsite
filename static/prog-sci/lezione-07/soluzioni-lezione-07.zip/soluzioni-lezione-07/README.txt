SOLUZIONI DEGLI ESERCIZI — LEZIONE 07

Generato automaticamente dalle slide (genera_soluzioni.py).
Non modificare questi file: la sorgente sono le slide.

* Esercizio (5 min): il setter
    cartella: esercizio-il-setter
    file:     soluzione.cpp
    compila:  g++ -std=c++17 -Wall soluzione.cpp -o esegui
    stampa:
        n: lr 0.05
        m: peso 0.7, lr 0.1
        [setLr] rifiutato 5: deve stare in (0, 1]. Tengo 0.1
        [setLr] rifiutato 99: deve stare in (0, 1]. Tengo 0.1

* Esercizi lampo: cosa stampa?
    cartella: lampo/esercizi-lampo-cosa-stampa
    file:     quesito1.cpp
    compila:  g++ -std=c++17 -Wall quesito1.cpp -o esegui
    stampa:
        default
        param
        copia
        param

