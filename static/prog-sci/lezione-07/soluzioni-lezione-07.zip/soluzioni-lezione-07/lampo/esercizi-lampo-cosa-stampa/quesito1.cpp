#include <iostream>

class D {
public:
    D()          { std::cout << "default\n"; }
    D(double)    { std::cout << "param\n"; }
    D(const D&)  { std::cout << "copia\n"; }
};

int main() {
    D a;
    D b(1.0);
    D c = b;
    D d = D(2.0);
}
