#include <iostream>

class D {
public:
    D()          { std::cout << "default\n"; }
    D(double)    { std::cout << "param\n"; }
    D(const D&)  { std::cout << "copia\n"; }
};

int main() {
    D a;
    D b = a;
    D c;
    c = a;
    c = 3.0;
}
