#include "./pvector.hpp"
int main(void)
{
  rng.seed(1);                // fixed seed: the same random numbers at every run
  const int M = 1000000;      // number of random vectors
  const ntype L = 10.0;       // side of the box
  pvector R, U;

  // random(L): each component uniform in [-L/2, L/2)
  ntype rmin = L, rmax = -L, x2 = 0;
  for (int k = 0; k < M; k++)
    {
      R.random(L);
      for (int i = 0; i < NT; i++)
        {
          if (R(i) < rmin) rmin = R(i);
          if (R(i) > rmax) rmax = R(i);
        }
      x2 += R(0)*R(0);
    }
  std::cout << "random(L): min=" << rmin << " max=" << rmax
            << " <x^2>=" << x2/M << " (exact L^2/12=" << L*L/12 << ")\n";

  // random_orient(): uniform on the unit sphere
  ntype dnmax = 0, z = 0, z2 = 0, cap = 0;
  for (int k = 0; k < M; k++)
    {
      U.random_orient();
      ntype dn = fabs(U.norm() - 1.0);
      if (dn > dnmax) dnmax = dn;
      z  += U(2);
      z2 += U(2)*U(2);
      if (U(2) > 0.5) cap++;  // spherical cap z > 1/2: a quarter of the sphere
    }
  std::cout << "random_orient(): max|norm-1|=" << dnmax << "\n"
            << "  <z>=" << z/M << " (exact 0)  <z^2>=" << z2/M << " (exact 1/3)"
            << "  P(z>1/2)=" << cap/M << " (exact 1/4)\n";
  return 0;
}
