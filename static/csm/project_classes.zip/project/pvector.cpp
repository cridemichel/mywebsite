#include "./pvector.hpp"
int main(void)
{
  pvector A = {1.0, 2.0, 3.0}, B = {0.5, -1.0, 2.0}, C;
  const pvector K = {1.1, -2.5, 3.5};

  std::cout << "A(1)=" << A(1) << "\n";   // operator(): read
  A(1) = 5.0;                             // operator(): write
  std::cout << "A=" << A << "\n";         // operator<<
  std::cout << "K(2)=" << K(2) << "\n";   // const operator()

  C = 2.0*A;         std::cout << "2.0*A=" << C << "\n";
  C = rint(K);       std::cout << "rint(K)=" << C << "\n";
  C = mulcw(A, B);   std::cout << "mulcw(A,B)=" << C << "\n";
  C = divcw(A, B);   std::cout << "divcw(A,B)=" << C << "\n";
  std::cout << A << " " << B << "\n";     // chained <<
  return 0;
}
