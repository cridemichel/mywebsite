#include "./pvector.hpp"
int main(void)
{
  pvector P, P1;
  pvector V;
 
  V = P.operator+(P1);
  V.set(1,2.0);
  return 0;
}
