#include "./pvector.hpp"
int main(void)
{
  pvector P, P1;
  pvector V;
 

  return 0;
}
