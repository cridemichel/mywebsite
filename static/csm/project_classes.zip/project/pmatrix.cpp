#include "./pmatrix.hpp"
int main(void)
{
  pmatrixq<double,3> A = {1, 2, 3, 4, 5, 6, 7, 8, 9};        // NT*NT numbers, row by row
  pmatrixq<double,3> B = {{2, 3, 2}, {3, 4, 5}, {8, 0, 1}};  // a list of rows
  pmatrixq<double,3> C;                                       // void constructor: all 0
  const pmatrixq<double,3> K = {{1, 0, 0}, {0, 2, 0}, {0, 0, 3}};

  std::cout << "A=" << A << "\n";
  std::cout << "B=" << B << "\n";
  std::cout << "A(1,2)=" << A(1,2) << "\n";    // operator(): read
  C(0,0) = 5.0;                                 // operator(): write
  std::cout << "C=" << C << "\n";
  std::cout << "K(2,2)=" << K(2,2) << "\n";    // const operator()
  C = A + B;   std::cout << "A+B=" << C << "\n";
  C = A - B;   std::cout << "A-B=" << C << "\n";
  std::cout << "A=" << A << " K=" << K << "\n"; // chained <<
  return 0;
}
