#include "./pmatrix.hpp"
int main(void)
{
  using ntype = double;       // type of the elements
  constexpr int NT = 3;       // size of the matrices
  pmatrixq<ntype,NT> A = {{1, 2, 3}, {4, 5, 6}, {7, 8, 10}};
  pmatrixq<ntype,NT> B = {{2, 0, 1}, {1, 3, 0}, {0, 1, 4}};
  pmatrixq<ntype,NT> C;
  const pmatrixq<ntype,NT> I = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
  pvector<ntype,NT> V = {1, 2, 3};

  std::cout << "A=" << A << "\n";
  std::cout << "B=" << B << "\n";
  std::cout << "A*2=" << A*2.0 << "\n";
  std::cout << "2*A=" << 2.0*A << "\n";
  std::cout << "A/2=" << A/2.0 << "\n";
  C = A;
  C += B;  std::cout << "C=A, C+=B: " << C << "\n";
  C -= B;  std::cout << "C-=B:      " << C << "\n";
  C *= 3.0; std::cout << "C*=3:      " << C << "\n";
  C /= 3.0; std::cout << "C/=3:      " << C << "\n";
  std::cout << "A*V=" << A*V << "\n";
  std::cout << "V*A=" << V*A << "\n";
  std::cout << "A*B=" << A*B << "\n";
  std::cout << "B*A=" << B*A << "\n";          // the product is not commutative
  C = A;
  C *= B;  std::cout << "C=A, C*=B: " << C << "\n";
  std::cout << "transpose(A)=" << A.transpose() << "\n";
  std::cout << "A*I==A: " << (A*I == A) << "  I*A==A: " << (I*A == A)
            << "  A==B: " << (A == B) << "\n";
  std::cout << "(A*B)^T==B^T*A^T: "
            << ((A*B).transpose() == B.transpose()*A.transpose()) << "\n";
  return 0;
}
