#ifndef _SIMCLASS_
#define _SIMCLASS_
/*
 * X = done 
 * * = todo
 * E = exercise
 * OE = optional exercise
 *
 *  ===== base class (common stuff for MC and MD) =====  
 *
 *   [*]  calcenergyi()
 *   [*]  totenergy()
 *   [*]  pbc() [ to apply pbc ]
 *   [*]  save_mgl_snapshot() save configurations in mgl format
 *   [*]  prepare_initial_conf() 
 *   [*]  init_rng()
 *   [X]  run() method (main loop) 
 *
 *  ===== MC class =====
 *
 *  NTV ensemble 
 *
 *   [ ]  alpha()
 *   [ ]  acc()
 *   [ ]  move_NTV()
 *
 *   [ ]  calc_acceptance and adjust()
 *   [ ]  init_measures() truncate measure files
 *   [ ]  save_measures() append measures
 *
 *   [OE]  calculate tail corrections to energy and pressure
 *
 *  optional exercises:
 *
 *   // in "sim" base class
 *   [OE]  save_snapshot() save configurations 
 *   [OE]  save_restart()
 *   
 *   NPT ensemble 
 *
 *   // in "mcsim" derived class
 *
 *   [ ] init_measures() and save_measures(): add density saving
 *
 *   [ ] modify run() method to attempt box moves too
 *   
 *   NPT ensemble:
 *
 *   [ ] restore_all_pars (restore positions of all particles)
 *
 *   [ ] store_all_pars (store position of all particles)
 *
 *   [ ] alpha_box() i.e. trial box move
 *   
 *   [ ] acc_box() i.e. acceptance of trial box move
 *
 *** MD class [ 09/01/2026 ]
 *
 *   [ ]  init_measures() truncate measure files
 *
 *   [ ]  calcK() calculate the total kinetic energy
 *   
 *   [ ]  save_measures() save measures
 *   
 *   [ ]  gauss() (gauss stochastic variable using Box-Muller)
 *   
 *   [ ]  calc_forces()  <---
 *   
 *   [ ]  run() (implement velocity verlet as a symmetric factorization of propagator) <---
 *   
 *   [ ]  prepare_initial_conf() (initialize velocities) <---
 *   
 *
 */
#include <vector>
#include <string>
#include <fstream>
#include "./params.hpp"
#include "./particle.hpp"
#include "./randnumgen.hpp"
#include <iomanip> // for setprecision()

template<typename ntype, typename particle_type>
class sim
{
  using simp = simpars<ntype>;
protected:
  simp pars;  // parameters (by composition)
  std::vector<particle_type> parts;
  // if opt=1 calculate energies only for i < j
  ntype calcenergyi(int i, int opt=0) 
    {
    }
  
  ntype totenergy(void)
    {
    }

  void pbc(int i) 
    {
    }

  void save_mgl_snapshot(long int t) 
    {
    }
 
public:
  void prepare_initial_conf(void) 
    {
    }

  void set_sim_type(int type)
    {
      pars.simtype = type;
    }
 
  void init_rng(int n) 
    {
    }

  void run(void) 
    {
      // intentionally void
    }; 
};

#endif
