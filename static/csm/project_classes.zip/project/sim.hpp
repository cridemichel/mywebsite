#ifndef _SIMCLASS_
#define _SIMCLASS_
/*
 * X = done 
 * * = todo
 * E = exercise
 * OE = optional exercise
 *
 *  ===== base class (common stuff for MC and MD) =====  
 *
 *   [X]  calcenergyi()
 *   [X]  totenergy()
 *   [X]  pbc() [ to apply pbc ]
 *   [X]  save_mgl_snapshot() save configurations in mgl format
 *   [X]  prepare_initial_conf() 
 *   [X]  init_rng()
 *   [X]  run() method (main loop) 
 *
 *  ===== MC class =====
 *
 *  NTV ensemble 
 *
 *   [*]  alpha()
 *   [*]  acc()
 *   [*]  move_NTV()
 *
 *   [*]  calc_acceptance and adjust()
 *   [*]  init_measures() truncate measure files
 *   [*]  save_measures() append measures
 *
 *   [OE]  calculate tail corrections to energy and pressure
 *
 *  optional exercises:
 *
 *   // in "sim" base class
 *   [OE]  save_snapshot() save configurations 
 *   [OE]  save_restart()
 *   
 *   NPT ensemble 
 *
 *   // in "mcsim" derived class
 *
 *   [ ] init_measures() and save_measures(): add density saving
 *
 *   [ ] modify run() method to attempt box moves too
 *   
 *   NPT ensemble:
 *
 *   [ ] restore_all_pars (restore positions of all particles)
 *
 *   [ ] store_all_pars (store position of all particles)
 *
 *   [ ] alpha_box() i.e. trial box move
 *   
 *   [ ] acc_box() i.e. acceptance of trial box move
 *
 *   [ ] move_box() 
 *
 *** MD class [ 09/01/2026 ]
 *
 *   [ ]  init_measures() truncate measure files
 *
 *   [ ]  calcK() calculate the total kinetic energy
 *   
 *   [ ]  save_measures() save measures
 *   
 *   [ ]  gauss() (gauss stochastic variable using Box-Muller)
 *   
 *   [ ]  calc_forces()  <---
 *   
 *   [ ]  run() (implement velocity verlet as a symmetric factorization of propagator) <---
 *   
 *   [ ]  prepare_initial_conf() (initialize velocities) <---
 *   
 *
 */
#include <vector>
#include <string>
#include <fstream>
#include "./params.hpp"
#include "./particle.hpp"
#include "./randnumgen.hpp"
#include <iomanip> // for setprecision()

template<typename ntype, typename particle_type>
class sim
{
  using simp = simpars<ntype>;
protected:
  simp pars;  // parameters (by composition)
  std::vector<particle_type> parts;
  // if opt=1 calculate energies only for i < j
  ntype calcenergyi(int i, int opt=0) 
    {
      int j;
      ntype enei=0.0;
      for (j=0; j < pars.Np; j++) // pars.Np is the total number of particles
        {
          if (opt==1 && i >= j)
            continue;
          if (i==j)
            continue;
          // the particle class must provide a method vij to calculate the interaction energy
          enei += parts[i].vij(parts[j], pars.L); 
          // pars.L is a vector with the sides of the box 
        }
      return enei;
    }
  
  ntype totenergy(void)
    {
      ntype ene=0.0;

      for (auto i=0; i < static_cast<int>(parts.size()); i++)
        {
          ene+=calcenergyi(i, 1);
        }
      return ene;
    }

  void pbc(int i) 
    {
      auto Dr = parts[i].r;
      Dr = mulcw(pars.L,rint(divcw(Dr,pars.L))); // L*rint(Dr/L)
      parts[i].r = parts[i].r - Dr;
    }

  void save_mgl_snapshot(long int t) 
    {
       std::fstream f;
       std::string s;

       s = "cnf-" + std::to_string(t) + ".mgl";
       f.open(s, std::ios::out|std::ios::trunc);
       for (int i=0; i < pars.Np; i++)
         {
           f << parts[i].r(0) << " " << parts[i].r(1) << " " <<
             parts[i].r(2) << " @ " << pars.sigma*0.5 << "\n";
         }
       f.close();
    }
 
public:
  void prepare_initial_conf(void) 
    {
      // SC 
      int ix, iy, iz;
      int cc=0;
      pars.Np = pars.nx*pars.ny*pars.nz;
      parts.resize(pars.Np);
      ntype vcell = pow(pars.sigma,3.0);
      ntype rhomax = 1.0/vcell;
      ntype sf;
      sf = cbrt(rhomax/pars.rho);
      pars.L ={ntype(pars.nx), ntype(pars.ny), ntype(pars.nz)};
      ntype clen = sf*pars.sigma;
      pars.L *= clen;
      std::cout << "Box size is " << pars.L << "\n";
      std::cout << "Initial density is " << pars.Np/(pars.L(0)*pars.L(1)*pars.L(2)) << "\n";
      for (ix = 0; ix < pars.nx; ix++)
        for (iy = 0; iy < pars.ny; iy++)
          for (iz = 0; iz < pars.nz; iz++)
            {
              parts[cc].r = {ix*clen, iy*clen, iz*clen};
              parts[cc].r -= pars.L*0.5;
              parts[cc].set_sigma(pars.sigma);
              parts[cc].set_epsilon(pars.epsilon);
              parts[cc].set_rcut(pars.rc);
              cc++;
            }
      // ...or BCC or FCC lattice
 
    }

  void set_sim_type(int type)
    {
      pars.simtype = type;
    }
 
  void init_rng(int n) 
    {
      if (n < 0)
        rng.rseed();
      else
        rng.seed(n);
    }

  void run(void) 
    {
      // intentionally void
    }; 
};

template<typename ntype, typename particle_type>
class mcsim: public sim<ntype, particle_type>
{
  // for calc_acceptance_and_adjust: total trial moves and accepted ones
  // for calculating acceptance rates.
  using bc=sim<ntype, particle_type>;
  using bc::calcenergyi, bc::parts, bc::pars, 
        bc::totenergy, bc::save_mgl_snapshot, bc::pbc;
  
  // counters used to calculate acceptance rates
  long int tot_tra, tot_vol, tra_rej, vol_rej;

  // displacement pars.deltra
  // move particle i by using as max displacement parameter pars.deltra
  // and apply PBC
  void alpha(int i)
    {
    }

  // ACCEPT OR REJECT TRIAL MOVE ACCORDING TO METROPOLIS CRITERION
  // We assume kB=1 (Boltzmann constant) so that beta=1/T.
  // Calculate new energy and accept move with probability
  // min {1, exp(-\beta deltaU)}, i.e.
  // if deltaU < 0 accept the move
  // otherwise generate a random number xi in [0,1)
  // and if xi < exp(-beta*deltaU) accept the move otherwise reject it
  void acc(int i, ntype eno)
    {
    }
 
  // 1) calculate energy of particle i
  // 2) store position of particle i
  // 3) trial move
  // 4) acceptance
  void move_NTV(int i)
    {
    }

  void move_box(void)// <------------------------------------------------
    {
    }

  // trial box move
  //
  // 1) choose randomly a new volume
  //
  // 2) scale all particle positions and box size by factor "fact"
  //
  // 3) calculate new total interaction energy
  //
  // 4) calculate \DeltaG (see pdf of lectures)
  void alpha_box(ntype& DG, ntype& fact)
    {
    }

  // accept or reject box move
  //
  // 1) calculate e^{-\Delta G} (see pdf of lectures)
  // 2) generate a random number \xi and check whether to accept the box trial move
  // 3) if move is rejected:
  //    i)   restore all particle positions through method restore_all_pars()
  //    ii)  restore box size
  //    iii) update counter vol_rej of rejected box moves for calculating acceptance ratio
  void acc_box(ntype DG, ntype fact)
    {
    }

 // restore all particle positions
 void restore_all_pars()
   {
   }

 // store all particle position
 void store_all_pars()
   {
   }

  // CALC ACCEPTANCE RATES AND
  // ADJUST pars.deltra
  // adjust maximum volume "displacement" in alpha_box
  // so that acceptance rate of box move is around 0.5
  void calc_acceptance_and_adjust(void)
    {
    }

  // open files in writing mode to truncate them to 0
  void init_measures(void)
    {
    }

 // save potential energy per particle
 void save_measures(long int t)
    {
    }

 public:
  void run(void) 
    {
      // loop over MC steps
      int i, t, ip;
      tot_tra = tra_rej = tot_vol = vol_rej = 0;
      init_measures();
      if (pars.simtype==0)
        std::cout << "MC-NTV\n";
      else
        std::cout << "MC-NPT\n";
      for (t = 0; t < pars.totsteps; t++)
        {
          // ATTEMPT TO MOVE ALL PARTICLES:
          // Np move attempts = 1 MC step
          for (i=0; i < pars.Np; i++)
            {
              ip = rng.ranf()*pars.Np;
              move_NTV(ip);
              tot_tra++;
            }
        
          if (t > 0 && pars.savemeasure > 0 && t % pars.savemeasure == 0)
            {
              save_measures(t);
            }

          if (t > 0 && t % pars.outstps == 0) 
            {
              std::cout << "Step #" << t << "\n";
              // NOTE: to compare with Johnson paper data the internal energy must be calculated (i.e. by including
              // the kinetic contribution)
              std::cout << "total energy per particle is " << totenergy()/pars.Np << "\n";
            }

          if (t > 0 && pars.save_mgl_snapshot > 0 && 
              t % pars.save_mgl_snapshot == 0)
            {
              save_mgl_snapshot(t);
            }

          if (t > 0 && pars.adjstps > 0 && t % pars.adjstps == 0 && 
              t < pars.maxadjstps)
            {
              calc_acceptance_and_adjust();
            }
        }
    } 
};
#endif
