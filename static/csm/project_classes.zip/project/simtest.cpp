#include "./sim.hpp"
// A class derived from sim, only to test the methods of the
// base class: a derived class can use the protected members
// of sim (as mcsim will do).
template<typename ntype, typename particle_type>
class simtest: public sim<ntype, particle_type>
{
  using bc = sim<ntype, particle_type>;
  using bc::pars, bc::parts, bc::calcenergyi, bc::totenergy,
        bc::pbc, bc::save_mgl_snapshot;
public:
  // the tests below assume a 10x10x10 lattice and rc = 5
  void set_test_pars(void)
    {
      pars.nx = pars.ny = pars.nz = 10;
      pars.rc = 5.0;
    }

  void run(void) // it hides sim::run()
    {
      ntype V = pars.L(0)*pars.L(1)*pars.L(2);
      std::cout << "Np=" << pars.Np << "  L=" << pars.L
                << "  density=" << pars.Np/V << "\n";

      // tra_move(), store() and restore() on particle 7
      pvector<ntype,3> r7 = parts[7].r, d = {0.1, 0.2, 0.3};
      parts[7].store();
      parts[7].tra_move(d);
      bool moved = (parts[7].r - r7 - d).norm() < 1e-12;
      parts[7].restore();
      bool back = (parts[7].r - r7).norm() < 1e-12;
      std::cout << "tra_move: " << moved
                << "  store/restore: " << back << "\n";

      // vij(): particles 0 and 1 are nearest neighbours, at
      // distance a = rho^(-1/3); so are 0 and 9, through the
      // minimum image (the lattice has 10 sites along each side)
      std::cout << "vij(0,1)=" << parts[0].vij(parts[1], pars.L)
                << "  vij(0,9)=" << parts[0].vij(parts[9], pars.L)
                << "\n";

      // totenergy() and calcenergyi(): on the lattice all the
      // particles are equivalent, each one has energy 2U/Np
      ntype U = totenergy();
      std::cout << "U/Np=" << U/pars.Np
                << "  E_0/2=" << calcenergyi(0)/2
                << "  E_555/2=" << calcenergyi(555)/2 << "\n";

      // pbc(): move particle 555 by (L, -L, 2L), then bring
      // it back into the box
      pvector<ntype,3> r0 = parts[555].r;
      parts[555].tra_move({pars.L(0), -pars.L(1), 2*pars.L(2)});
      pbc(555);
      std::cout << "pbc: particle 555 back to its site: "
                << ((parts[555].r - r0).norm() < 1e-10) << "\n";

      // save_mgl_snapshot(): one line for each particle
      save_mgl_snapshot(0);
      std::ifstream f("cnf-0.mgl"); // a file for reading
      std::string first, line;
      int nl = 0;
      if (std::getline(f, first)) // false at the end
        nl = 1;
      while (std::getline(f, line))
        nl++;
      std::cout << "cnf-0.mgl: " << nl
                << " lines, the first one is: " << first << "\n";
    }
};

int main(void)
{
  simtest<double, particleLJ<double>> st;
  // init_rng(): the same seed gives the same random numbers
  st.init_rng(5);
  double x1 = rng.ranf();
  st.init_rng(5);
  double x2 = rng.ranf();
  std::cout << "init_rng(5) twice, the same number: "
            << (x1 == x2) << "\n";

  st.init_rng(0);
  st.set_test_pars();
  st.prepare_initial_conf(); // simple cubic lattice
  st.run();
  return 0;
}
