#include "./sim.hpp"
// A class derived from sim, only to test the methods of the
// base class: a derived class can use the protected members
// of sim (as mcsim will do).
template<typename ntype, typename particle_type>
class simtest: public sim<ntype, particle_type>
{
  using bc = sim<ntype, particle_type>;
  using bc::pars, bc::parts, bc::calcenergyi, bc::totenergy,
        bc::pbc, bc::save_mgl_snapshot;
public:
  void run(void) // it hides sim::run()
    {
      ntype V = pars.L(0)*pars.L(1)*pars.L(2);
      std::cout << "Np=" << pars.Np << "  L=" << pars.L
                << "  density=" << pars.Np/V << "\n";

      // tra_move(), store() and restore() on particle 7
      pvector<ntype,3> r7 = parts[7].r, d = {0.1, 0.2, 0.3};
      parts[7].store();
      parts[7].tra_move(d);
      bool moved = (parts[7].r - r7 - d).norm() < 1e-12;
      parts[7].restore();
      bool back = (parts[7].r - r7).norm() < 1e-12;
      std::cout << "tra_move: " << moved
                << "  store/restore: " << back << "\n";

      // vij(), fij() and set_vcut(): particles 0 and 1 are
      // nearest neighbours, at distance a; F must be equal to
      // -grad v (by finite differences), w to r.F
      ntype v, vs, w, h = 1e-6;
      parts[0].set_vcut();
      auto F = parts[0].fij(parts[1], pars.L, v, vs, w);
      pvector<ntype,3> G, Dr = parts[0].r - parts[1].r;
      Dr = Dr - mulcw(pars.L, rint(divcw(Dr, pars.L)));
      for (int k=0; k < 3; k++)
        {
          particle_type P = parts[0], M = parts[0];
          P.r(k) += h;
          M.r(k) -= h;
          G(k) = -(P.vij(parts[1], pars.L)
                   - M.vij(parts[1], pars.L))/(2*h);
        }
      std::cout << "vij(0,1)=" << parts[0].vij(parts[1], pars.L)
                << "  fij: v=" << v << " v-vs=" << v-vs
                << " w=" << w << " |F|=" << F.norm() << "\n";
      std::cout << "F=-grad v: " << ((F - G).norm() < 1e-6)
                << "  w=r.F: " << (fabs(w - Dr*F) < 1e-12) << "\n";

      // totenergy() and calcenergyi(): on the lattice all the
      // particles are equivalent, each one has energy 2U/Np
      ntype U = totenergy();
      std::cout << "U/Np=" << U/pars.Np
                << "  E_0/2=" << calcenergyi(0)/2
                << "  E_555/2=" << calcenergyi(555)/2 << "\n";

      // pbc(): move particle 555 by (L, -L, 2L), then bring
      // it back into the box
      pvector<ntype,3> r0 = parts[555].r;
      parts[555].tra_move({pars.L(0), -pars.L(1), 2*pars.L(2)});
      pbc(555);
      std::cout << "pbc: particle 555 back to its site: "
                << ((parts[555].r - r0).norm() < 1e-10) << "\n";

      // save_mgl_snapshot(): one line for each particle
      save_mgl_snapshot(0);
      std::ifstream f("cnf-0.mgl"); // a file for reading
      std::string first, line;
      int nl = 0;
      if (std::getline(f, first)) // false at the end
        nl = 1;
      while (std::getline(f, line))
        nl++;
      std::cout << "cnf-0.mgl: " << nl
                << " lines, the first one is: " << first << "\n";
    }
};

int main(void)
{
  simtest<double, particleLJ<double>> st;
  // init_rng(): the same seed gives the same random numbers
  st.init_rng(5);
  double x1 = rng.ranf();
  st.init_rng(5);
  double x2 = rng.ranf();
  std::cout << "init_rng(5) twice, the same number: "
            << (x1 == x2) << "\n";

  st.init_rng(0);
  st.prepare_initial_conf(); // simple cubic lattice
  st.run();
  return 0;
}
