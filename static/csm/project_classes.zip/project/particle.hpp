#ifndef _PARTICLE_
#define _PARTICLE_
/*
 * X = done 
 * * = todo
 * E = exercise
 * OE = optional exercise 
 *
 * particle class
 *
 * MC 
 *
 * [*] store/restore methods
 * 
 * [*] tra_move()
 * 
 * MD 
 * 
 * [E] expiLq  <----
 *
 * [E] expiLp  <----
 *
 * particleLJ class 
 *
 * [*] vij()
 * 
 * [ ] set_vcut()
 *
 * [ ] fij()  <----
 *
 * particleSS class
 *
 * [ ] vij()
 * 
 * [OE] set_vcut()
 * 
 * [OE] fij)
 *
 */
#include "./pvector.hpp"
template<typename ntype>
class particle
{
  pvector<ntype,3> rold; // to store particle's position 
protected:
  ntype vcut;
public:
  ntype sigma, epsilon, rc, m; // mass (m) for MD
  pvector<ntype,3> r, v, f; // velocity (v) and force (f) for MD 

  // vcut = vLJ(rc), i.e. the value of LJ potential at r=rc
  // this method should be called when initializing particles
  void set_vcut(void);
 
  void tra_move(pvector<ntype,3> delr)
    {
    }

  void store()
    {
    }

  void restore()
    {
    }
  void set_sigma(ntype sig)
    {
      sigma = sig;
    }

  void set_epsilon(ntype eps)
    {
      epsilon = eps;
    }

  void set_rcut(ntype rcut)
    {
      rc = rcut;
    }

  void set_mass(ntype mass)
    {
      m = mass;
    }

  particle()
    {
      sigma=1.0;
      epsilon=1.0;
      rc=2.5;
      vcut = 0.0;
      m = 1.0;
    }

};

template <typename ntype>
class particleLJ: public particle<ntype>
{
  using pt=particle<ntype>;
protected:
  using pt::vcut;
public:
  using pt::r, pt::epsilon, pt::rc, pt::sigma;
  ntype vij(particleLJ P, pvector<ntype,3> L)
    {
    }
};
#endif 
