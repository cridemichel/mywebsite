// X = done
// * = to discuss
// E = exercise for students
// N = don't do
#ifndef _PMATRIX_
#define _PMATRIX_ 
// pmatrixq<double,3> M;
// M = {1.,2.,3.,4.,5.,6.,7.,8.,9.};
// 
// [*] constructor with initializer_list
// [*] overloading of () operator (m(i,j))
// [*] overloading of << operator to print a matrix
// [*] matrix addition and subtraction
// [ ] += and -= operators
// [ ] matrix times scalar (also *=)
// [ ] matrix divided by scalar (also /=) 
// [ ] scalar times matrix <--- with friend function
// [ ] matrix times vector 
// [ ] vector times matrix <--- with friend function
// [ ] matrix times matrix (also *=)
// [ ] transpose
// [ ] operator == to pmatrix class
// 
#include "./pvector.hpp"
template <typename ntype, int NT>
class pmatrixq
{
  ntype m[NT][NT];
public:
  ~pmatrixq()
    {

    }
  pmatrixq()
    {
      for (int i=0; i < NT; i++)
        for (int j=0; j < NT; j++)
          m[i][j]=0;
    }

  // to initialize a matrix as follows: pmatrixq<double,2> M={1,2,3,4};
  pmatrixq(std::initializer_list<ntype> list)
    {
    } 

  // to initialize a matrix as follows: pmatrixq<double,2> M={{1,2},{3,4}};
  pmatrixq(std::initializer_list<std::initializer_list<ntype>> list)
    {
    } 

  // ============================================================
  // overloading of () operator to get/set (i,j)-th element
  // m(i,j)=2.0;
  // std::cout << m(i, j);
  ntype& operator()(int i, int j)
    {
     }
  
  ntype operator()(int i, int j) const
    {
    }

  // output (std::cout << M) << "\n";
  friend std::ostream& operator<<(std::ostream& os, const pmatrixq& M1)
    {
    }

  // addition 
  pmatrixq operator+(const pmatrixq &M2) const
    {
    }
  // subtraction
  pmatrixq operator-(const pmatrixq &M2) const
    {
    }

};
#endif
