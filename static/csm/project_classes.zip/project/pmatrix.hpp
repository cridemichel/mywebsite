// X = done
// * = to discuss
// E = exercise for students
// N = don't do
#ifndef _PMATRIX_
#define _PMATRIX_ 
// pmatrixq<double,3> M;
// M = {1.,2.,3.,4.,5.,6.,7.,8.,9.};
// 
// [X] constructor with initializer_list
// [X] overloading of () operator (m(i,j))
// [X] overloading of << operator to print a matrix
// [X] matrix addition and subtraction
// [*] += and -= operators
// [*] matrix times scalar (also *=)
// [*] matrix divided by scalar (also /=) 
// [*] scalar times matrix <--- with friend function
// [*] matrix times vector 
// [*] vector times matrix <--- with friend function
// [*] matrix times matrix (also *=)
// [*] transpose
// [*] operator == to pmatrix class
// 
#include "./pvector.hpp"
template <typename ntype, int NT>
class pmatrixq
{
  ntype m[NT][NT];
public:
  ~pmatrixq()
    {

    }
  pmatrixq()
    {
      for (int i=0; i < NT; i++)
        for (int j=0; j < NT; j++)
          m[i][j]=0;
    }

  // to initialize a matrix as follows: pmatrixq<double,2> M={1,2,3,4};
  pmatrixq(std::initializer_list<ntype> list)
    {
      int cc=0;
      for (auto el: list)
        {
          if (cc < NT*NT)
            m[cc/NT][cc%NT] = el;
          cc++;  
        }
      for ( ; cc < NT*NT; cc++) // shorter list: the others are 0
        m[cc/NT][cc%NT] = 0;
    } 

  // to initialize a matrix as follows: pmatrixq<double,2> M={{1,2},{3,4}};
  pmatrixq(std::initializer_list<std::initializer_list<ntype>> list)
    {
      for (int i=0; i < NT; i++) // first all 0: missing ones stay 0
        for (int j=0; j < NT; j++)
          m[i][j]=0;
      int i=0, j=0;
      for (auto r: list)
        {
          j=0;
          for (auto c: r)
            {
              if (i < NT && j < NT)
                m[i][j] = c;
              j++;
            }
          i++;
        }
    } 

  // ============================================================
  // overloading of () operator to get/set (i,j)-th element
  // m(i,j)=2.0;
  // std::cout << m(i, j);
  ntype& operator()(int i, int j)
    {
      return m[i][j];
     }
  
  ntype operator()(int i, int j) const
    {
      return m[i][j];
    }

  // output (std::cout << M) << "\n";
  friend std::ostream& operator<<(std::ostream& os, const pmatrixq& M1)
    {
      int i, j;
      os << "{";
      for (i=0; i < NT; i++)
        {
          os << "{";
          for (j=0; j < NT; j++)
            {
              os << M1(i,j);
              if (j < NT-1)
                os << ",";
            }
          os << "}";
          if (i < NT-1)
            os << ",";
        }
      os << "}";
      return os;
    }

  // addition 
  pmatrixq operator+(const pmatrixq &M2) const
    {
      // MT = M1 + M2
      pmatrixq MT;
      for (auto i=0; i < NT; i++)
        {
          for (auto j=0; j < NT; j++)
            {
              MT(i,j) = (*this)(i,j) + M2(i,j);
            }
        }
      return MT;
    }
  // subtraction
  pmatrixq operator-(const pmatrixq &M2) const
    {
      // MT = M1 - M2
      pmatrixq MT;
      for (auto i=0; i < NT; i++)
        {
          for (auto j=0; j < NT; j++)
            {
              MT(i,j) = (*this)(i,j) - M2(i,j);
            }
        }
      return MT;
    }

  // ============== LAB #5: skeletons, fill the bodies

  // M1 += M2
  pmatrixq& operator+=(const pmatrixq &M2)
    {
    }

  // M1 -= M2
  pmatrixq& operator-=(const pmatrixq &M2)
    {
    }

  // matrix *= scalar
  pmatrixq& operator*=(const ntype& s)
    {
    }

  // matrix /= scalar
  pmatrixq& operator/=(const ntype& s)
    {
    }

  // matrix times scalar: M*s
  pmatrixq operator*(const ntype& s) const
    {
    }

  // matrix divided by scalar: M/s
  pmatrixq operator/(const ntype& s) const
    {
    }

  // scalar times matrix: s*M (friend function, as "scalar times vector")
  friend pmatrixq operator*(const ntype& s, const pmatrixq &M2)
    {
    }

  // matrix times vector: (M*V)(i) = sum over j of M(i,j)*V(j)
  pvector<ntype,NT> operator*(const pvector<ntype,NT> &V2) const
    {
    }

  // vector times matrix: (V*M)(j) = sum over i of V(i)*M(i,j) (friend function)
  friend pvector<ntype,NT> operator*(const pvector<ntype,NT>& V1, const pmatrixq& M2)
    {
    }

  // matrix times matrix: (M1*M2)(i,j) = sum over k of M1(i,k)*M2(k,j)
  pmatrixq operator*(const pmatrixq &M2) const
    {
    }

  // M1 *= M2, i.e. M1 = M1*M2
  pmatrixq& operator*=(const pmatrixq &M2)
    {
    }

  // transpose: MT(i,j) = M(j,i)
  pmatrixq transpose(void) const
    {
    }

  // M1 == M2: true if all the elements are equal
  bool operator==(const pmatrixq &M2) const
    {
    }

};
#endif
