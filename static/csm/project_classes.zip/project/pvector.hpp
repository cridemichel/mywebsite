#ifndef _PVECTOR_
#define _PVECTOR_
// EXERCISE create an efficient vector class in C++ with methods and overloaded operators which you can find in the TODO LIST.
// TODO LIST:
// * = TODO, X = done, E = exercise
// [X] standard constructor/destructor
// [X] constructor 
// [X] show()
// [X] overloading of = assignment 
// [X] overloading of + operator for addition of vectors
// [X] overloading of - operator for subtraction of vectors
// [X] sum() method to sum two vectors
// [X] get( ) (get i-th element)
// [X] set( , ) (set i-th element)
// [*] constructor with overloading->initializer_list
// [*] overloading of += and -= operators with vectors
// [*] overloading of * operator for scalar product (vector times vector)
// [*] norm() norm of vector, implemented by using overloaded operator "*"
// [*] overloading of * operator for "vector times scalar" product
// [*] overloading of / operator for "vector divided by scalar" product
// [*] overloading of *= and /= (with scalars)
// [*] overloading of operator == (check whether two vectors are equal)
// [*] overloading of ^ operator for cross product 
// [ ] overloading of (...) operator () to use vector as C arrays, e.g. v(0)=1
// [ ] "scalar times vector" through friend function
// [ ] rint(), i.e. if V is a vector rint(V) is the vector with components rounded to nearest integer
// [ ] mulcw, multiplication element wise: C=mulcw(A,B), i.e. C(i) = A(i)*B(i)
// [ ] divcw, division element wise: C=divcw(A,B), i.e. C(i) = A(i)/B(i)
// [ ] overloading of << for output (friend function)
//
// Discuss random number generator class with Mersenne-Twister
// [ ] random(L), random vector inside a box of length L
// [ ] random_orient() random unit on unit sphere (marsaglia) 

#include<iostream> // input/output
#include<cmath>
#include<string>
#include<initializer_list> // std::initializer_list (constructor with braces)
#include<cstdlib> // exit()
// STRATEGIES TO MAKE CLASS GENERIC
#define NT 3
// constexpr tells compiler that NT can be calculated at compile time
//constexpr int NT=3;

//typedef float ntype; // as in C
using ntype=double; // use "using" to define an alias for the keyword "double"

class pvector
{
  ntype v[NT]; // private member
public:

  pvector() // void constructor
    {
      // initialize the vector
      for (int i=0; i < NT; i++)
        v[i]=0;
      //std::cout << "void constructor\n";
    }

  ~pvector() // destructor
    {
      // nothing to do
      //std::cout << "void destructor\n";
    }

  // ============== LAB #2: skeleton, fill the body
  // curly brace initialization, i.e.
  // pvector V={1.0,2.0,3.0};
  pvector(std::initializer_list<ntype> L)  // overloading constructor
    {

    }

  // Note this method does not change data of object hence it is declared "const"
  void show(std::string s="") const // default argument
    {
      std::cout << s << "("; 
      for (int i=0; i < NT; i++)
        {
          std::cout << v[i];
          if (i < NT-1)
            std::cout << ",";
        }
      std::cout << ")\n";
    }

  // since assign operator returns pvector objects by reference:
  // Note this method changes data of object hence it is *not* declared "const"
  pvector& assign( const pvector& P1)
    {
      for (int i=0; i < NT; i++)
        v[i] = P1.v[i];
      return (*this);
    }

  pvector& operator=(const pvector& V2)
    {
      for (int i=0; i < NT; i++)
        v[i] = V2.v[i];
      return (*this);

    }

  // method to sum two vectors
  pvector sum(const pvector &V2) const
    {
      pvector VT;
      for (int i=0; i < NT; i++)
        {
          VT.v[i] = v[i] + V2.v[i];
        }
      return VT;
    }

  // addition operator overloading
  // Note this method does not change data of object hence it is declared "const"
  pvector operator+(const pvector& V2) const
    {
      pvector VT;
      for (int i=0; i < NT; i++)
        {
          VT.v[i] = v[i] + V2.v[i];
        }
      return VT;
    } 

  // subtraction operator overloading
  // Note this method does not change data of object hence it is declared "const"
  pvector operator-(const pvector& V2) const
    {
      pvector VT;
      for (int i=0; i < NT; i++)
        {
          VT.v[i] = v[i] - V2.v[i];
          // equivalently:
          // VT.v[i] = (*this).v[i] - V2.v[i];
        }
      return VT;
    } 

  // get value of a vector element
  // Note this method does not change data of object hence it is declared "const"
  ntype get(int i) const
    {
      return v[i];
    }

  // set value of vector element
  ntype set(int i, ntype val) 
    {
      return v[i]=val;
    }

  // ============== LAB #2: skeletons, fill the bodies

  // add vector and assign
  pvector& operator+=(const pvector& V2)
    {

    }

  // subtract vector and assign
  pvector& operator-=(const pvector& V2)
    {

    }

  // scalar product (vector times vector)
  ntype operator*(const pvector& V2) const
    {

    }

  // norm of vector
  ntype norm(void) const
    {

    }

  // vector times scalar 
  // A*s <=> A.operator*(s)
  pvector operator*(ntype s) const
    {

    }

  // vector divided by scalar 
  pvector operator/(ntype s) const
    {

    }

  // multiply by scalar and assign result to vector
  pvector& operator*=(ntype s)
    {

    }

  // divide by scalar and assign result to vector
  pvector& operator /=(ntype s)
    {

    }

  // compare two vectors
  bool operator==(const pvector& V2) const
    {

    }

  // cross product: only for 3D vectors
  pvector operator^(const pvector& V2) const
    {

    }
};
#endif
