#ifndef _PVECTOR_
#define _PVECTOR_
// EXERCISE create an efficient vector class in C++ with methods and overloaded operators which you can find in the TODO LIST.
// TODO LIST:
// * = TODO, X = done, E = exercise
// [*] standard constructor/destructor
// [*] constructor (with overloading->initializer_list)
// [*] show()
// [*] overloading of = assignment 
// [*] overloading of + operator for addition of vectors
// [*] overloading of - operator for substraction of vectors
// [*] sum() method to sum two vectors
// [*] get( ) (get i-th element)
// [*] set( , ) (set i-th element)
// [ ] overloading of += and -= operators with vectors
// [ ] overloading of * operator for scalar product (vector times vector)
// [ ] norm() norm of vector, implemented by using overloaded operator "*"
// [ ] overloading of * operator for "vector times scalar" product
// [ ] overloading of / operator for "vector divided by scalar" product
// [ ] overloading of *= and /= (with scalars)
// [ ] overloading of operator == (check whether two vectors are equal)
// [ ] overloading of ^ operator for cross product 
// [ ] overloading of (...) operator () to use vector as C arrays, e.g. v(0)=1
// [ ] "scalar times vector" through friend function
// [ ] rint(), i.e. if V is a vector rint(V) is the vector with components rounded to nearest integer
// [ ] mulcw, multiplication element wise: C=mulcw(A,B), i.e. C(i) = A(i)*B(i)
// [ ] divcw, division element wise: C=divcw(A,B), i.e. C(i) = A(i)*B(i)
// [ ] overloading of << for output (friend function)
//
// Discuss random number generator class with Mersenne-Twister
// [ ] random(L), random vector inside a box of length L
// [ ] random_orient() random unit on unit sphere (marsaglia) 

#include<iostream> // input/output
#include<cmath>
#include<string>
// STRATEGIES TO MAKE CLASS GENERIC
#define NT 3
// constexpr tells compiler that NT can be calculated at compile time
//constexpr int NT=3;

//typedef float ntype; // as in C
using ntype=double; // use "using" to define an alias for the keyword "double"

class pvector
{
  ntype v[NT]; // private member
public:

  pvector() // void constructor
    {

    }

  ~pvector() // destructor
    {

    }


  // Note this method does not change data of object hence it is declared "const"
  void show(std::string s="") const // argomento di default 
    {

    }

  pvector& operator=(const pvector& V2)
    {
      for (int i=0; i < NT; i++)
        v[i] = V2.v[i];
      return (*this);

    }

  // method to sum two vectors
  pvector sum(const pvector &V2) const
    {

    }

  // addition operator overloading
  // Note this method does not change data of object hence it is declared "const"
  pvector operator+(const pvector& V2) const
    {

    } 

  // subtraction operator overloading
  // Note this method does not change data of object hence it is declared "const"
  pvector operator-(const pvector& V2) const
    {

    } 

  // get value of a vector element
  // Note this method does not change data of object hence it is declared "const"
  ntype get(int i) const
    {
    }

  // set value of vector element
  ntype set(int i, ntype val) 
    {
    }

};
#endif
