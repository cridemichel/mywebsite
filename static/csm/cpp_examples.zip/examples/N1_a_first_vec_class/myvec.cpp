#include "./myvec.hpp"
int main(int argc, char** argv)
{
  // class instantiation
  myvec v;

  // initialize array elements
  for (int i=0; i < v.length(); i++)
    {
      v.set(i, 0);
    }
  // print out value of third element
  std::cout << "v[2]=" << v.get(2) << std::endl;

  // set 2-th element  
  v.set(1, 1);

  // set 3-th element  
  v.set(2, -2);

  std::cout << "v[1]=" << v.get(1) << " v[2]=" << v.get(2) << std::endl;
}
