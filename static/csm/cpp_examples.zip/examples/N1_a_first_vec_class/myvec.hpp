#include<iostream>
class myvec
{
  // private members
  int v[3]; // array of integers
  int len; // allocated int
public:
  // constructor
  myvec()
    {
      len=3;
    }
  // destructor
  ~myvec()
    {
      // do nothing
    }

  // assign value to (i+1)-th element of the array
  void set(int i, int val)
    {
      v[i] = val;
    }

  // get (i+1)-th element of array
  int get(int i) const // pass implicitly argument (*this) with const modifier, 
                       //it means that this method does not change the state of the object
    {
      return v[i];
    }
  // get actual length of array
  int length(void) const
    {
      return len;
    }
 };

