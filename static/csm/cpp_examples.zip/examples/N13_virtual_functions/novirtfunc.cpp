#include<iostream>

// BASE CLASS
class base
{
  void no_virt_func(char *txt) // no_virt_func() is not virtual!!!
    {
      std::cout << txt << " - method no_virt_func() of BASE class.\n";
    }
public:
  void printmsg(char* txt)
    {
      no_virt_func(txt);
    }

};

// DERIVED CLASS
class derived: public base
{
  void no_virt_func(char *txt)  // no_virt_func() is redefined but it is not virtual!!!
    {
      std::cout << txt << " - method no_virt_func() of DERIVED class.\n";
    }
public: 
};

int main(int argc, char **argv)
{
  char txt[2][256]={" hallo from object OA!", " hallo from object OB!"};
  base OA;
  derived OB;

  // OA is an instance of the base class
  OA.printmsg(txt[0]);

  // OB is an instance of the derived class
  OB.printmsg(txt[1]); // printmsg (which is a method of base class) calls no_virt_func()
                       // of base class and not the one in the derived class,
                       // even though OB is an instance of "derived" class
  return 0;
}
