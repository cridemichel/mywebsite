#include<iostream>

// BASE CLASS
class base
{
  virtual void virt_func(char *txt) // virt_func() is virtual!!!
    {
      std::cout << txt << " - method virt_func() of the BASE class.\n";
    }
public:

  void printmsg(char* txt)
    {
      virt_func(txt);
    }

};

// DERIVED CLASS
class derived: public base
{
  void virt_func(char *txt) override // virt_func() is redefined and it is virtual
    {
      std::cout << txt << " - method virt_func() of the DERIVED class.\n";
    }
public: 
};

int main(int argc, char **argv)
{
  char txt[2][256]={" hallo from object OA!", " hallo from object OB!"};
  base OA;
  derived OB;

  // OA is an instance of base class
  OA.printmsg(txt[0]);

  // OB is an instance of derived class
  OB.printmsg(txt[1]); // printmsg (which is a method of base class) now calls virt_func()
                       // of derived class
  return 0;
}
