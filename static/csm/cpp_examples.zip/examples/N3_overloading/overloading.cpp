#include "./overloading.hpp"
int main(void)
{
  vecdder v1, v2, v3;
  for (int i = 0; i < 3; ++i) {
    v1.set(i,i*i+1);
    v2.set(i,i*i+1);
  }
  v3 = v1 + v2;
  v3.show(); 
  return 0;
}
