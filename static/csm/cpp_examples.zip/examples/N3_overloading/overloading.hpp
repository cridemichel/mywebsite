#include "../N2_a_derived_vec_class/vecder.hpp"
class vecdder: public vecder
{
public:

  // ASSIGNMENT OPERATORS
  // return assigned object by reference (&)
  // so that one can write
  // and value 3 is assigned to i-th element of a

  // overloading of "=" operator
  // vecdded a, b;
  // a = b;
  vecdder& operator=(const vecdder& b)
    {
      // a=b;
      int i;
      for (i=0; i < length(); i++)
        set(i, b.get(i)); 
      return *this; // object *this is always implicitly passed to methods/operators
    }

  // SUM, SUBTRACTION, ...
  // default is to return the result as a copy since we need a temporary
  // object to perform the addition (see "vs" object below). If a reference was returned,
  // we would get a reference to a stack object, which will be overwritten!
  // c=  a.sum( b );
  // c = a + b
  //
  // sum method
  vecdder sum(const vecdder& b) const
    {
      vecdder vs;
      for (int i = 0; i < length(); ++i) {

        // DISCUSSION const methods 
        vs.set(i, get(i) + b.get(i)); 
      }
      return vs;
    }
  //  c = a + b; 
  // overloading of "+" operator
  vecdder operator+(const vecdder& b) const // 
    {
      vecdder vs;
      for (int i = 0; i < length(); ++i) {

        // DISCUSSION const methods 
        vs.set(i, get(i) + b.get(i)); 
      }
      return vs;
    }
};
