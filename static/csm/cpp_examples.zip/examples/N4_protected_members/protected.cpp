#include "./protected.hpp"
int main(int argc, char** argv)
{
  // class instantiation
  dercl v;
  v.c = 10;
  v.fc(); // we can use only public members of a class (not protected or private ones!)
}
