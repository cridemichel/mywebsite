#include<iostream>
class basecl
{
private: // this is redundant
  // private members
  int a;
  int fa(void)
    {
      return a;
    }
protected:
  int b; // allocated int
  int fb(void)
    {
      // fb() returns the value of member b
      return b;
    }
public:
  int c;
  int fc(void)
    {
      // fc() returns the value of member a
      return b;
    }
};

class dercl: public basecl
{
  int g(void)
    {
      fc();// this method is public
      fb(); // this method protected
      return b;
    }
};
