#include<cstdlib>
#include<iostream>
#include<stdio.h>
class myvec
{
  // private members
  int *v; // pointer to array
  int len; // allocated int
public:
  // constructor
  myvec()
    {
      len=0;
      v=nullptr;
    }
  // destructor
  ~myvec()
    {
      if (v!=nullptr)
        delete[] v;
    }

  // allocate memory for array
  void alloc(int l) 
    {
      len=l;
      v = new int[len];// new double[]
    }
  // assign value to (i+1)-th element of the array
  void set(int i, int val)
    {
      v[i] = val;
    }
  // get (i+1)-th element of array
  // a=V(i);
  // V(i) = 2.0;
  int get(int i) const // passare implicitamente l'argomento (*this) con il modificatore const
    {
      return v[i];
    }
  // get actual length of array
  int length(void) const
    {
      return len;
    }
  // resize array (enlarge)
  void resize(int l)
    {
      int *vt;
      vt = new int[l];
      // initialize with all elements and 0 if larger
      for (int i=0; i < l; i++)
	vt[i] = (i < len)?v[i]:0.0;
      len = l;
      if (v!=nullptr)
        delete [] v;
      v=vt;
    }
 };
