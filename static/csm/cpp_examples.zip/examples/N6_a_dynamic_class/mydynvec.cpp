#include "./mydynvec.hpp"
int main(int argc, char** argv)
{
  // class instantiation
  myvec v;

  // allocate memory
  v.alloc(10);

  // initialize array elements
  for (int i=0; i < 10; i++)
    {
      v.set(i, 0);
    }
  // print out value of third element
  std::cout << "v[2]=" << v.get(2) << std::endl;

  // resize the vector
  v.resize(11);

  // set 11-th element  
  v.set(10, -2);

  // print out third element and 11-th one
  std::cout << "v[2]=" << v.get(2) << " v[10]=" << v.get(10) << std::endl;
}
