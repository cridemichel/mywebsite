#include<cstdlib>
#include<iostream>
// a generic class (a metaclass or class template)
// ntype can be float, double, long double, ...
constexpr int NT=3;// <---- like #define

template <typename ntype>
class genvec
{
  // private members
  ntype v[NT];

public:

  void set(int i, ntype val)
    {
      v[i] = val;
    }
 
   ntype get(int i) const
    { 
      return v[i];
    }

  void show(void) const
    {
      std::cout << "(";
      for (int i = 0; i < NT; i++) 
        {
          std::cout << get(i);
          if (i < NT-1)
            std::cout << ",";
          else
            std::cout << ")\n";
        }
    }
  genvec()
    {
    }

  ~genvec()
    {
    }
};
