#include "./genvec.hpp"
int main(void)
{
  genvec<double> gv; 
  for (int i = 0; i < 3; ++i) {
    gv.set(i, i+0.1);
  }
  gv.show();
  return 0;
}
