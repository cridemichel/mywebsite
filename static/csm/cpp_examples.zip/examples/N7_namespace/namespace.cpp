#include<iostream>
int c; // global variable
namespace nsA
{
  int a; // nsA::a
  int b; // nsA::b
}
namespace nsB
{
  int a; // nsB::a
  int b; // nsB::b
}
namespace nsC
{
  int a; // nsC::a
  int b; // nsC::b
}

// using namespace nsC;
// using namespace std;

int main(int argc, char**argv)
{
  nsA::a = 1;
  nsB::a = 2;
  nsC::a = 3; // default namespace is nsC (see using namespace nsC above)
  std::cout << "nsA::a=" << nsA::a << "\n";
  std::cout << "nsB::a=" << nsB::a << "\n";
  std::cout << "nsC::a=" << nsC::a << "\n";

  return 0;
}
