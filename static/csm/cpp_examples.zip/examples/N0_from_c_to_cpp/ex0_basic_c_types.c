#include<stdio.h>
int main(void)
{
  /* basic types */
  int a, b, c, i;
  double d, e, f;
  /* double is a class */
  /* d, e and f are instances of the class double */ 
  a=1;
  b=2;
  c = a + 2;

  d = 1.2;
  e = 2.3;
  f = d + e;
  printf("a=%d b=%d c=%d\n", a, b, c);
  printf("d=%f e=%f f=%f\n", d, e, f);

  /* vectors */

  double va[3]={1.2, 1.3, -1.0};
  double vb[3]={0.2, 0.1, 0.4}; 
  double vc[3];
  // vc = va + vb  
  for (i = 0; i < 3; i++)
    {
      vc[i] = va[i] + vb[i];
    }
  printf("va=(");
  for (i = 0; i < 3; i++)
    {
      printf("%f", va[i]);
      if (i < 2)
        printf(",");
    } 
  printf("\n");
  printf("vb=(");
  for (i = 0; i < 3; i++)
    {
      printf("%f", vb[i]);
      if (i < 2)
        printf(",");
    } 

  printf("\n");
  printf("vc=va+vb=(");
  for (i = 0; i < 3; i++)
    {
      printf("%f", vc[i]);
      if (i < 2)
        printf(",");
    } 
  printf(")\n");
}
