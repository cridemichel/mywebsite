#include<iostream>
#include<string>
class myclass 
{
//private:
  int a;
  std::string txt; // private member (an int)
  void show_private(void) const // private method/function 
    {
      std::cout << "no\n!" << std::endl;
    }
public:

void show(void) const
  {
    show_private();  
    std::cout << txt << " " << a << " " << std::endl;
  }

myclass() // constructor
  {
    // constructor (called when creating object)
    txt = "Hallo World";
    std::cout << "Object created" << std::endl;
    a=2;
  }

~myclass() // destructor
  {
    std::cout << "Object destroyed" << std::endl;
  }
};
