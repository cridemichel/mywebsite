#include "./ex2_a_cpp_class.hpp"
int main(void)
{
  myclass C; // a new type!


  C.show();
}
