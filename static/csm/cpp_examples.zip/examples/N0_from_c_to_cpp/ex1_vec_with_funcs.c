#include<stdio.h>
void sumvec(double va[3], double vb[3], double vc[3]);

void printvec(double vec[3], char* txt);

int main(void)
{
  /* basi types */
  int i;
  double va[3]={1.2, 1.3, -1.0}, vb[3]={0.2, 0.1, 0.4}, vc[3];
  
  /* ... or better with functions */
  sumvec(va, vb, vc);
  printvec(va, "va");
  printvec(vb, "vb");
  printvec(vc, "vc=va+vb");
}


void printvec(double vec[3], char* txt)
{
  int i;
  printf("%s=(", txt);
  for (i = 0; i < 3; i++)
    {
      printf("%f", vec[i]);
      if (i < 2)
        printf(",");
    } 
  printf(")\n");
 
}

void sumvec(double va[3], double vb[3], double vc[3])
{
  int i;
  for (i=0; i < 3; i++)
    {
      vc[i] = va[i] + vb[i];
    }
}
