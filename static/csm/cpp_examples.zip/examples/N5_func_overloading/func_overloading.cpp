#include "./func_overloading.hpp"
int main(void)
{
  vecddder v1;
  for (int i = 0; i < 3; ++i) {
    v1.set(i,i); // initialize elements of vector v1
  }
  v1.show(); // show content
  v1.show("v3:"); // show content using overloaded method show() (see func_overloading.hpp file)
  v1.show(1);
  return 0;
}
