#include "../N3_overloading/overloading.hpp"
class vecddder: public vecdder
{
public:
  // For overloading, we need to explicitly say that we want to use show
  // of base class method as public method of derived class too
  using vecder::show;
  // overloading of show method which now has an argument (a string)
  void show(std::string txt) const
    {
      std::cout << txt;
      vecder::show();
    }
  void show(int a) const
    {
      std::string s;
      // we can add string 
      // and convert integer or float to strings
      s = "v" + std::to_string(a) + "=";
      show(s);
    }

};
