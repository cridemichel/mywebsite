#include<iostream>
#include"../N1_a_first_vec_class/myvec.hpp"
class vecder: public myvec
{
public: 
  // we add just a show public method to this derived class
  void show(void) const
    {
      std::cout << "(";
      for (int i = 0; i < length(); ++i) { 
        // note that length() is a public method of base class 
          {
            std::cout << get(i); // get() is another public method of public class
          }
        if (i < length()-1)
          std::cout << ",";
        else
          std::cout << ")" << std::endl;
      }
    }
};
