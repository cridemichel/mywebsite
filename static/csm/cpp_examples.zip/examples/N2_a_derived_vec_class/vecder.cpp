#include "./vecder.hpp"
int main(int argc, char** argv)
{
  vecder vd;
  for (int i=0; i < vd.length(); i++)
    {
      vd.set(i, i); // initialize elements of vector vd
    }
  vd.show(); // show content of vector vd
}
