#include<iostream>
class Acl
{
  double da;
public:
  Acl() // constructor
    {
      da = 1.0;
    }
  void showA(void)
    {
      std::cout << da << "\n";
    }
};

class Bcl
{
  // same name as in Acl: Derive inherits both, Acl::da and Bcl::da,
  // so D.da would not compile ("request for member 'da' is ambiguous")
  double da;
public:
  Bcl() // constructor
    {
      da = 2.0;
    }
  void showB(void)
    {
      std::cout << da << "\n";
    } 
};

class Compose // COMPOSITION
{
  int c;
public:
  Acl A;
  Bcl B;
};

class Derive: public Acl, public Bcl // DERIVATION
{
  int c;
public:
};


int main(void)
{
  Derive D;
  Compose C;
  D.showA();
  D.showB();
  C.A.showA();
  C.B.showB();
  //C.B.showA();
}
