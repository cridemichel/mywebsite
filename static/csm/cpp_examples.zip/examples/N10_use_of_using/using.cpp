#include<iostream>
template <typename ntype>
class base {
public:
  void funcbase(void)
    {
      std::cout << "hallo ";
    }
  ntype a;
};

template <typename ntype>
class derived: public base<ntype> {
public:
  using bt = base<ntype>; // this is just an alias (from c++11 on, i.e. use at least -std=c++11 to compile)
  using base<ntype>::a, bt::funcbase; // if we remove this we got a compilation error
  void funcder(void)
    {
      funcbase();
      std::cout << "from derived: " << a << "\n";
    }
  derived(ntype x) // constructor
    {
      a = x;
    }
};

int main(void)
{
  derived<double> A(1.1);
  A.funcder();
  return 0;
}

