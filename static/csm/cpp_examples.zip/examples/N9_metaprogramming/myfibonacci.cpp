#include<iostream>
#include<tuple>
using namespace std;
// FIBONACCI SERIES: F_{n} = F_{n-1} + F_{n-2}
template<int N>
class fib {
public:
static constexpr long int value = fib<N-1>::value + fib<N-2>::value;
// tuple_cat constructs a tuple that is a concatenation of all tuples provided as args. 
// E.g. int a=1;
//      string s="pippo";
//      float f=1.3;
//      auto t=tuple_cat(make_tuple(a), make_tuple(s));
//      auto t2=tuple_cat(t, f);
//      results in the tuple whose elements are:
//      {1, "pippo", 1.3} 
// Note that make_tuple is necessary since this way we convert value to a tuple which can be added to the present tuple
// by tuple_cat. 
static constexpr auto fis = tuple_cat(fib<N-1>::fis, make_tuple(value)); // add value to the tuple
};

// stop recursion
template<>
class fib<1> {
public:
static constexpr long int value = 1;
static constexpr tuple<long int> fis = make_tuple(1);
};

template<>
class fib<0> {
public:
static constexpr long int value = 0;
};

// type to hold an integer
template<int N> struct int_{static constexpr int n=N;};

template <class T, class I>
void print_tuple(T l, I nel)
{
  cout << get<tuple_size<T>::value-nel.n>(l) << ","; // print n-th element
  int_<nel.n-1> nn;
  print_tuple(l, nn); // recursively print remaining elements
}

// stop recursion
template <class T>
void print_tuple(T l, int_<1>) // we simply provide a type as second argument since istance of second argument is not used  
{
  cout << get<tuple_size<T>::value-1>(l) << "\n";
}
// the following varadic function calls print_tuple where second argument is the number of elements of the tuple
template<class T>
void print_tuple(T l)
{
  print_tuple(l, int_<tuple_size<T>::value>()); // int_<tuple_size<T>::value>() is an object of type struct int_
}
int main()
{
  constexpr int N = 100;
  fib<N> f;
  cout << "The Fibonacci sequence up to N=" << N << " is:\n"; 
  print_tuple(f.fis);
}
