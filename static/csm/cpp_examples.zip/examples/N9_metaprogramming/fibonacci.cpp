/* FIBONACCI - METAPROGRAMMING */
#include <iostream>
#include <tuple>
using namespace std;
// FIBONACCI SERIES: F_{n} = F_{n-1} + F_{n-2}
template<std::size_t> 
struct int_
{};

// declaration of generic print_tuple function to recursively print a tuple
template <class Tuple, size_t Pos>
std::ostream& print_tuple(std::ostream& out, const Tuple& t, int_<Pos> ) {
  out << std::get< std::tuple_size<Tuple>::value-Pos >(t) << ',';
  return print_tuple(out, t, int_<Pos-1>());
}

// overloading of generic print_tuple function to stop recursion
template <class Tuple>
std::ostream& print_tuple(std::ostream& out, const Tuple& t, int_<1> ) {
  return out << std::get<std::tuple_size<Tuple>::value-1>(t);
}

// overloading of << operator to print a tuple
template <class... Args>
ostream& operator<<(ostream& out, const std::tuple<Args...>& t) {// tuple<Args...> is a generic tuple
  print_tuple(out, t, int_<sizeof...(Args)>()); // sizeof...(Args) returns the number of arguments of a variadic template 
  return out;
}

// sum of the results of two Fibonacci classes
template <typename A, typename B> struct Sum
{
  static constexpr long long int value = A::result+B::result;
};
template <int N> struct Fibonacci 
{
  using pterm=Fibonacci<N-1>;
  using ppterm=Fibonacci<N-2>;
  static constexpr long long int result=Sum<pterm,ppterm>::value;
  // add result to the tuple
  static constexpr auto lista = std::tuple_cat(Fibonacci<N-1>::lista,std::make_tuple(result));
};

// overloading of generic class Fibonacci to stop recursion
template <> struct Fibonacci<1>  
{
  static constexpr long long int result=1;
  static constexpr std::tuple<long long int> lista {1}; // the sequence starts with F_1 = 1
};
template <> struct Fibonacci<0>  
{
  static constexpr long long int result=0;
};


int main(void)
{
  constexpr int N=45; // number of elements of the fibonacci series
  typedef Fibonacci<N> F;
  auto items=F::lista;

  cout << "Fibonacci sequence up to N=" << N << ": ";

  std::cout << items << std::endl;
}
