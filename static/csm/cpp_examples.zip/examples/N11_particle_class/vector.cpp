#include<iostream>
#include<vector>
template <typename ntype>
class particle
{
  ntype rx, ry, rz;
public:
  void show(void)
    {
      std::cout << "particle position is (" << rx << "," << ry << "," << rz << ")\n";
    }
  void set_pos(ntype x, ntype y, ntype z)
    {
      rx = x;
      ry = y;
      rz = z;
    }
};
int main(int argc, char **argv)
{
  using pt = particle<float>; // using to define an alias
  std::vector<pt> p; // vector of particles 
  p.resize(2); // two particles
  p[0].set_pos(1,2,3);
  p[1].set_pos(4,5,6);
  p[0].show();
  p[1].show();
  return 0;
}
